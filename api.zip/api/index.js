const express = require('express');
const app = express();
const router = require('./router/api');

app.use((req, res, next) => {
    req.userIP = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    next();
});

// Use API router
app.use("/api", router);

// Route for web application
app.get('/', (req, res) => {
  try {
    return res.status(403).json({ 
      status: '403 Forbidden', 
      creator: '@kimzzDev', 
      message: 'You are not allowed to use this API',
      userIP: req.userIP
    });
  } catch (error) {
    console.error('Error while fetching user IP:', error.message);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Port
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
