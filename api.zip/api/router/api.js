const express = require('express');
const router = express.Router();
const axios = require('axios');
const api = require('kimzz-scraper');
const ytdl = require('ytdl-core')
const yt = require('./ytdl-core')
const fs = require('fs');
const { TiktokDownloader } = require("@tobyg74/tiktok-api-dl")
const path = require('path');
const kimzz = '@kimzzDev';
const key = '@kimzzdev';

const tik = {
	'normal_model': 'v2',
	'v1': 'TiktokAPI',
	'v2': 'SSSTik',
	'v3': 'MusicalDown'
}

// Define a function to generate a random file name
function getRandom(extension) {
    return Math.random().toString(36).substring(2, 15) + extension;
}

function formatAngka(angka) {
    if (angka >= 1000000) {
      return (angka / 1000000).toFixed(1) + 'M';
    } else if (angka >= 1000) {
      return (angka / 1000).toFixed(1) + 'k';
    } else {
      return angka.toString();
    }
  }


router.get('/ai/remini', async (req, res) => {
    const apikey = req.query.apikey;
    const url = req.query.url;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!url) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Url images diperlukan untuk menggunakan fitur remini' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await api.scraper.remini(url);
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: {
                url: data.image_url,
                size: data.image_size
            }     
        }); 
    } catch (error) {
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

router.get('/ai/removebg', async (req, res) => {
    const apikey = req.query.apikey;
    const url = req.query.url;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!url) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Url images diperlukan untuk menggunakan fitur removebg' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await api.scraper.removebg(url);
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: {
                url: data.image_url,
                size: data.image_size
            }     
        }); 
    } catch (error) {
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

router.get('/stream/ytmp3', async (req, res) => {
    const url = req.query.url;
    const apikey = req.query.apikey;

    if (!url) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Url Youtube diperlukan untuk menggunakan fitur ytmp3 stream' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }

    try {
        // Generate a random file name for the temporary mp3 file
        const mp3FileName = getRandom('.mp3');

        // Define the file path where the mp3 file would be temporarily stored
        const filePath = path.join(__dirname, '..', 'temp', mp3FileName); // Menetapkan jalur absolut menggunakan path.join()

        // Get information about the YouTube video
        const videoInfo = await ytdl.getInfo(url);

        // Create a readable stream for the audio content of the YouTube video
        const audioStream = ytdl(url, { filter: 'audioonly' });

        // Create a writable stream to save the audio content to a temporary file
        const fileStream = fs.createWriteStream(filePath);
        audioStream.pipe(fileStream);

        // Once the file is written, set HTTP headers for the response
        fileStream.on('finish', () => {
            // Memeriksa apakah file ada dan dapat diakses sebelum mengirimkannya
            if (fs.existsSync(filePath)) {
                res.sendFile(filePath, () => {
                    // Remove the temporary file after sending
                    fs.unlinkSync(filePath);
                });
            } else {
                res.status(404).send('File not found');
            }
        });

    } catch (error) {
        console.error('Error streaming audio:', error.message);
        res.status(500).send('Internal Server Error');
    }
});

router.get('/download/ytmp3', async (req, res) => {
    const apikey = req.query.apikey;
    const url = req.query.url;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!url) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Url youtube diperlukan untuk menggunakan fitur ytmp3 downloader' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await yt.ytDonlodMp3(url);
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: data
        }); 
    } catch (error) {
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

router.get('/download/ytmp4', async (req, res) => {
    const apikey = req.query.apikey;
    const url = req.query.url;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!url) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Url youtube diperlukan untuk menggunakan fitur ytmp3 downloader' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await yt.ytDonlodMp4(url);
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: data
        }); 
    } catch (error) {
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

router.get('/download/fbdl', async (req, res) => {
    const apikey = req.query.apikey;
    const url = req.query.url;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!url) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Url facebook diperlukan untuk menggunakan fitur facebook downloader' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await api.scraper.fbdl(url);
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: data.result
        }); 
    } catch (error) {
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

router.get('/download/igdl', async (req, res) => {
    const apikey = req.query.apikey;
    const url = req.query.url;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!url) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Url Instagram diperlukan untuk menggunakan fitur instagram downloader' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await api.scraper.igdl(url);
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: data.result
        }); 
    } catch (error) {
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

router.get('/download/tiktok', async (req, res) => {
    const apikey = req.query.apikey;
    const url = req.query.url;
    const model = req.query.model;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!url) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Url Tiktok diperlukan untuk menggunakan fitur tiktok downloader' });
    }
    if (!model) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Sila Pilih Model Tiktok Yang Tersedia', model: tik });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await TiktokDownloader(url, { version: model });
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: data.result
        }); 
    } catch (error) {
        console.log(error)
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

router.get('/download/spotify', async (req, res) => {
    const apikey = req.query.apikey;
    const url = req.query.url;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!url) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Url Spotify diperlukan untuk menggunakan fitur spotify downloader' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await api.scraper.spotifydl(url);
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: data.result
        }); 
    } catch (error) {
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

router.get('/search/spotify', async (req, res) => {
    const apikey = req.query.apikey;
    const query = req.query.query;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!query) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Query diperlukan untuk menggunakan fitur spotify Search Songs' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await api.scraper.spotifySearch(query);
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: data.result
        }); 
    } catch (error) {
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

router.get('/search/ttstalk', async (req, res) => {
    const apikey = req.query.apikey;
    const username = req.query.username;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!username) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Username diperlukan untuk mendapatkan maklumat user di tiktok' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await api.scraper.ttstalk(username);
        const follower = await formatAngka(data.result.followerCount)
        const following = await formatAngka(data.result.followingCount)
        const video = await formatAngka(data.result.videoCount)
        const friend = await formatAngka(data.result.friendCount)
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: {
                username: data.result.uniqueId,
                nickname: data.result.nickname,
                profile: data.result.avatarLarger,
                bio: data.result.singnature,
                verified: data.result.verified,
                follower: follower,
                following: following,
                video: video,
                friend: friend
            }
        }); 
    } catch (error) {
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

router.get('/search/igstalk', async (req, res) => {
    const apikey = req.query.apikey;
    const username = req.query.username;

    if (!apikey) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Apikey diperlukan untuk mengesahkan anda adalah pengguna terdaftar' });
    }
    if (!username) {
        return res.status(400).json({ status: '400 Bad Request', creator: kimzz, message: 'Username diperlukan untuk mendapatkan maklumat user di instagram' });
    }
    if (apikey !== key) {
        return res.status(403).json({ status: '403 Forbidden', creator: kimzz, message: 'Apikey yang diberikan tidak valid atau tidak terdaftar' });
    }
    try {
        const data = await api.scraper.igstalk(username);
        return res.status(200).json({ 
            status: '200 OK', 
            creator: kimzz, 
            result: data.result.user_info
        }); 
    } catch (error) {
        return res.status(500).json({ status: '500 Internal Server Error', creator: kimzz, message: 'Internal Server Error' });
    }
});  

module.exports = router;