const fs = require('fs')
const chalk = require('chalk')

// baileys
global.baileys = require('@whiskeysockets/baileys') 
global.adiwajshing = require('@adiwajshing/baileys') 
global.adjiwajshingg = ["@adiwajshing/baileys"]
// baileys

// EDIT DISINI
global.owner = ["60146351257"]// your number
global.namaBot = "Kimzz botz" // your name bot
global.version = ['1.0.0'] // jgn usik
global.namaCreator = ["Kimzz Hosting"] // your name
global.sessionName = 'kimzz' // jgn usik eror 
global.wlcm = []
global.wlcmm = []
global.apikey = "kimzzstore"
global.apitokendo = "-"
global.apilinode = "-"

// tumbal database
global.premium = JSON.parse(fs.readFileSync('./database/premium.json')) // jgn usik ntar eror
global.jangan = JSON.parse(fs.readFileSync('./database/idgrup.json')) // jgn usik ntar eror
global.scammer = JSON.parse(fs.readFileSync('./database/database.json')) // jgn usik ntar eror

// new
global.mess = {
    wait: 'wait a moment, we are processing your request 🫠',
    succes: 'Your request has been successfully sent 🥳',
    eror: 'We are sorry, we are unable to process your request 🙃',
    OnlyOwner: 'Sorry, this feature can only be accessed by the owner Only 🗿',
    OnlyPremium: 'Sorry, this feature can only be accessed by the Premium User 😺',
    OnlyGroup: 'Sorry, this feature can only be used in groups, it cannot be used in private chat 🥹',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})
