require('./settings')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType } = global.baileys

const fs = require("fs");
const cheerio = require("cheerio");
const chalk = require("chalk");
const { api } = require('kimzz-apis')
const os = require('os')
const speed = require('performance-now')
const crypto = require("crypto");
const { exec, spawn, execSync } = require("child_process");
const axios = require("axios");
const moment = require("moment-timezone");
const fetch = require("node-fetch");
const Jimp = require("jimp");
const util = require("util");
const jsobfus = require('javascript-obfuscator');
const { sizeFormatter} = require("human-readable")
const format = sizeFormatter()
const { color, bgcolor, mycolor } = require('./lib/color')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif')
const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, parseMention, getRandom } = require('./lib/functions')
const logo = fs.readFileSync("./audio/logo.jpg")
const { TelegraPh } = require("./lib/TelegraPH")
const apikey = ["kimzzstore"]

module.exports = kimzz = async (kimzz, m, chatUpdate, store) => {
try {
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°#*+,.?=''():√%!¢£¥€π¤ΠΦ_&`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°#*+,.?=''():√%¢£¥€π¤ΠΦ_&!`™©®Δ^βα¦|/\\©^]/gi) : '.'
const chath = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == "listResponseMessage") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == "messageContextInfo") ? m.message.listResponseMessage.singleSelectReply.selectedRowId : ''
const content = JSON.stringify(m.message)
const { type, quotedMsg, mentioned, now, fromMe } = m
const isCmd = body.startsWith(prefix)
const from = m.key.remoteJid
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const full_args = body.replace(command, '').slice(1).trim()
const args = body.trim().split(/ +/).slice(1)
const pushname = m.pushName || "No Name"
const botNumber = await kimzz.decodeJid(kimzz.user.id)
const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender) 
const itsMe = m.sender == botNumber ? true : false
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const { chats } = m
const API_TOKEN = global.apitokendo;
const LINODE_API_TOKEN = global.apilinode;
const isPremium = [botNumber, ...global.premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender) 

const tanggal = moment.tz('Asia/Kuala_Lumpur').format('DD/MM/YY')
const hari = moment.tz("Asia/Kuala_Lumpur").format("dddd");
const jam = moment.tz('Asia/Kuala_Lumpur').format("HH:mm:ss");
const salam = moment(Date.now()).tz('Asia/kuala_Lumpur').locale('id').format('a')
const isGroup = m.key.remoteJid.endsWith('@g.us')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await kimzz.groupMetadata(m.chat).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
const groupOwner = m.isGroup ? groupMetadata.owner : ''
const groupMembers = m.isGroup ? groupMetadata.participants : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const welcm = m.isGroup ? wlcm.includes(from) : false
const welcmm = m.isGroup ? wlcmm.includes(from) : false

const me = m.sender
const getCase = (cases) => {
return "case  "+`'${cases}'`+fs.readFileSync("./index.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
}
const totalFitur = () =>{
var mytext = fs.readFileSync("./index.js").toString()
var numUpper = (mytext.match(/case '/g) || []).length;
return numUpper
        }
if (!kimzz.public) {
if (!m.key.fromMe) return
}
// database scammer 
const cekscammer = JSON.parse(fs.readFileSync('./database/database.json'))
const scammer = global.scammer
const prem = JSON.parse(fs.readFileSync("./database/premium.json"))

// function text random
const galau = [
    "Gak salah kalo aku lebih berharap sama orang yang lebih pasti tanpa khianati janji-janji",
    "Kalau aku memang tidak sayang sama kamu ngapain aku mikirin kamu. Tapi semuanya kamu yang ngganggap aku gak sayang sama kamu",
    "Jangan iri dan sedih jika kamu tidak memiliki kemampuan seperti yang orang miliki. Yakinlah orang lain juga tidak memiliki kemampuan sepertimu",
    "Hanya kamu yang bisa membuat langkahku terhenti, sambil berkata dalam hati mana bisa aku meninggalkanmu",
    "Tetap tersenyum walaluku masih dibuat menunggu dan rindu olehmu, tapi itu demi kamu",
    "Tak semudah itu melupakanmu",
    "Secuek-cueknya kamu ke aku, aku tetap sayang sama kamu karena kamu telah menerima aku apa adanya",
    "Aku sangat bahagia jika kamu bahagia didekatku, bukan didekatnya",
    "Jadilah diri sendiri, jangan mengikuti orang lain, tetapi tidak sanggup untuk menjalaninya",
    "Cobalah terdiam sejenak untuk memikirkan bagaimana caranya agar kita dapat menyelesaikan masalah ini bersama-sama",
    "Bisakah kita tidak bermusuhan setelah berpisah, aku mau kita seperti dulu sebelum kita jadian yang seru-seruan bareng, bercanda dan yang lainnya",
    "Aku ingin kamu bisa langgeng sama aku dan yang aku harapkan kamu bisa jadi jodohku",
    "Cinta tak bisa dijelaskan dengan kata-kata saja, karena cinta hanya mampu dirasakan oleh hati",
    "Masalah terbesar dalam diri seseorang adalah tak sanggup melawan rasa takutnya",
    "Selamat pagi buat orang yang aku sayang dan orang yang membenciku, semoga hari ini hari yang lebih baik daripada hari kemarin buat aku dan kamu",
    "Jangan menyerah dengan keadaanmu sekarang, optimis karena optimislah yang bikin kita kuat",
    "Kepada pria yang selalu ada di doaku aku mencintaimu dengan tulus apa adanya",
    "Tolong jangan pergi saat aku sudah sangat sayang padamu",
    "Coba kamu yang berada diposisiku, lalu kamu ditinggalin gitu aja sama orang yang lo sayang banget",
    "Aku takut kamu kenapa-napa, aku panik jika kamu sakit, itu karena aku cinta dan sayang padamu",
    "Sakit itu ketika cinta yang aku beri tidak kamu hargai",
    "Kamu tiba-tiba berubah tanpa sebab tapi jika memang ada sebabnya kamu berubah tolong katakan biar saya perbaiki kesalahan itu",
    "Karenamu aku jadi tau cinta yang sesungguhnya",
    "Senyum manismu sangatlah indah, jadi janganlah sampai kamu bersedih",
    "Berawal dari kenalan, bercanda bareng, ejek-ejekan kemudian berubah menjadi suka, nyaman dan akhirnya saling sayang dan mencintai",
    "Tersenyumlah pada orang yang telah menyakitimu agar sia tau arti kesabaran yang luar biasa",
    "Aku akan ingat kenangan pahit itu dan aku akan jadikan pelajaran untuk masa depan yang manis",
    "Kalau memang tak sanggup menepati janjimu itu setidaknya kamu ingat dan usahakan jagan membiarkan janjimu itu sampai kau lupa",
    "Hanya bisa diam dan berfikir Kenapa orang yang setia dan baik ditinggalin yang nakal dikejar-kejar giliran ditinggalin bilangnya laki-laki itu semuanya sama",
    "Walaupun hanya sesaat saja kau membahagiakanku tapi rasa bahagia yang dia tidak cepat dilupakan",
    "Aku tak menyangka kamu pergi dan melupakan ku begitu cepat",
    "Jomblo gak usah diam rumah mumpung malam minggu ya keluar jalan lah kan jomblo bebas bisa dekat sama siapapun pacar orang mantan sahabat bahkan sendiri atau bareng setan pun bisa",
    "Kamu adalah teman yang selalu di sampingku dalam keadaan senang maupun susah Terimakasih kamu selalu ada di sampingku",
    "Aku tak tahu sebenarnya di dalam hatimu itu ada aku atau dia",
    "Tak mudah melupakanmu karena aku sangat mencintaimu meskipun engkau telah menyakiti aku berkali-kali",
    "Hidup ini hanya sebentar jadi lepaskan saja mereka yang menyakitimu Sayangi Mereka yang peduli padamu dan perjuangan mereka yang berarti bagimu",
    "Tolong jangan pergi meninggalkanku aku masih sangat mencintai dan menyayangimu",
    "Saya mencintaimu dan menyayangimu jadi tolong jangan engkau pergi dan meninggalkan ku sendiri",
    "Saya sudah cukup tahu bagaimana sifatmu itu kamu hanya dapat memberikan harapan palsu kepadaku",
    "Aku berusaha mendapatkan cinta darimu tetapi Kamunya nggak peka",
    "Aku bangkit dari jatuh ku setelah kau jatuhkan aku dan aku akan memulainya lagi dari awal Tanpamu",
    "Mungkin sekarang jodohku masih jauh dan belum bisa aku dapat tapi aku yakin jodoh itu Takkan kemana-mana dan akan ku dapatkan",
    "Datang aja dulu baru menghina orang lain kalau memang dirimu dan lebih baik dari yang kau hina",
    "Membelakanginya mungkin lebih baik daripada melihatnya selingkuh didepan mata sendiri",
    "Bisakah hatimu seperti angsa yang hanya setia pada satu orang saja",
    "Aku berdiri disini sendiri menunggu kehadiran dirimu",
    "Aku hanya tersenyum padamu setelah kau menyakitiku agar kamu tahu arti kesabaran",
    "Maaf aku lupa ternyata aku bukan siapa-siapa",
    "Untuk memegang janjimu itu harus ada buktinya jangan sampai hanya janji palsu",
    "Aku tidak bisa selamanya menunggu dan kini aku menjadi ragu Apakah kamu masih mencintaiku",
    "Jangan buat aku terlalu berharap jika kamu tidak menginginkanku",
    "Lebih baik sendiri daripada berdua tapi tanpa kepastian",
    "Pergi bukan berarti berhenti mencintai tapi kecewa dan lelah karena harus berjuang sendiri",
    "Bukannya aku tidak ingin menjadi pacarmu Aku hanya ingin dipersatukan dengan cara yang benar",
    "Akan ada saatnya kok aku akan benar-benar lupa dan tidak memikirkan mu lagi",
    "Kenapa harus jatuh cinta kepada orang yang tak bisa dimiliki",
    "Jujur aku juga memiliki perasaan terhadapmu dan tidak bisa menolakmu tapi aku juga takut untuk mencintaimu",
    "Maafkan aku sayang tidak bisa menjadi seperti yang kamu mau",
    "Jangan memberi perhatian lebih seperti itu cukup biasa saja tanpa perlu menimbulkan rasa",
    "Aku bukan mencari yang sempurna tapi yang terbaik untukku",
    "Sendiri itu tenang tidak ada pertengkaran kebohongan dan banyak aturan",
    "Cewek strong itu adalah yang sabar dan tetap tersenyum meskipun dalam keadaan terluka",
    "Terima kasih karena kamu aku menjadi lupa tentang masa laluku",
    "Cerita cinta indah tanpa masalah itu hanya di dunia dongeng saja",
    "Kamu tidak akan menemukan apa-apa di masa lalu Yang ada hanyalah penyesalan dan sakit hati",
    "Mikirin orang yang gak pernah mikirin kita itu emang bikin gila",
    "Dari sekian lama menunggu apa yang sudah didapat",
    "Perasaan Bodo gue adalah bisa jatuh cinta sama orang yang sama meski udah disakiti berkali-kali",
    "Yang sendiri adalah yang bersabar menunggu pasangan sejatinya",
    "Aku terlahir sederhana dan ditinggal sudah biasa",
    "Aku sayang kamu tapi aku masih takut untuk mencintaimu",
    "Bisa berbagi suka dan duka bersamamu itu sudah membuatku bahagia",
    "Aku tidak pernah berpikir kamu akan menjadi yang sementara",
    "Jodoh itu bukan seberapa dekat kamu dengannya tapi seberapa yakin kamu dengan Allah",
    "Jangan paksa aku menjadi cewek seperti seleramu",
    "Hanya yang sabar yang mampu melewati semua kekecewaan",
    "Balikan sama kamu itu sama saja bunuh diri dan melukai perasaan ku sendiri",
    "Tak perlu membalas dengan menyakiti biar Karma yang akan urus semua itu",
    "Aku masih ingat kamu tapi perasaanku sudah tidak sakit seperti dulu",
    "Punya kalimat sendiri & mau ditambahin? chat *.owner*"
]
async function loading () {
var kimzzmod = [
"ʟᴏᴀᴅɪɴɢ...",
"_Hello My Name is Kimzz_",
"_Base Script : Kimzz Store_",
"_Provider Api : Kimzz_",
"_Website api : https://api.kimzzoffc.me/_",
"_Thanks You For Waiting_"
]
let { key } = await kimzz.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})//Pengalih isu

for (let i = 0; i < kimzzmod.length; i++) {
/*await delay(10)*/
await kimzz.sendMessage(from, {text: kimzzmod[i], edit: key });//PESAN LEPAS
}
}
const time2 = moment().tz('Asia/Kuala_Lumpur').format('HH:mm:ss')
if(time2 < "23:59:00"){
var ucapanWaktu = 'Kimzz Store | Bebas Share'
}
if(time2 < "19:00:00"){
var ucapanWaktu = 'Kimzz Store | Bebas Share'
}
if(time2 < "18:00:00"){
var ucapanWaktu = 'Kimzz Store | Bebas Share'
}
if(time2 < "15:00:00"){
var ucapanWaktu = 'Kimzz Store | Bebas Share'
        }
if(time2 < "10:00:00"){
var ucapanWaktu = 'Kimzz Store | Bebas Share'
}
if(time2 < "05:00:00"){
var ucapanWaktu = 'Kimzz Store | Bebas Share'
}
if(time2 < "03:00:00"){
var ucapanWaktu = 'Kimzz Store | Bebas Share'
}
// cek database
const cekid = JSON.parse(fs.readFileSync('./database/idgrup.json'))

// database 
const pler = global.jangan
const jangan = m.isGroup ? pler.includes(m.chat) : false
    
// auto read
if (isCmd && m.isGroup) { console.log(chalk.bold.rgb(255, 178, 102)('\x1b[1;31m~\x1b[1;37m> [\x1b[1;32mCMD\x1b[1;37m]'), chalk.bold.rgb(153, 255, 153)(command), chalk.bold.rgb(204, 204, 0)("from"), chalk.bold.rgb(153, 255, 204)(pushname), chalk.bold.rgb(204, 204, 0)("in"), chalk.bold.rgb(255, 178, 102)("Group Chat"), chalk.bold('[' + args.length + ']')); }
if (isCmd && !m.isGroup) { console.log(chalk.bold.rgb(255, 178, 102)('\x1b[1;31m~\x1b[1;37m> [\x1b[1;32mCMD\x1b[1;37m]'), chalk.bold.rgb(153, 255, 153)(command), chalk.bold.rgb(204, 204, 0)("from"), chalk.bold.rgb(153, 255, 204)(pushname), chalk.bold.rgb(204, 204, 0)("in"), chalk.bold.rgb(255, 178, 102)("Private Chat"), chalk.bold('[' + args.length + ']')); }

// reply sticker
const kimzzWait = () => {
let kimzzStikRep = fs.readFileSync('./audio/wait.webp')
kimzz.sendMessage(from, { sticker: kimzzStikRep }, { quoted: m })
}
const kimzzAdmin = () => {
let kimzzStikRep = fs.readFileSync('./audio/admin.webp')
kimzz.sendMessage(from, { sticker: kimzzStikRep }, { quoted: m })
}
const kimzzBotAdmin = () => {
let kimzzStikRep = fs.readFileSync('./audio/botadmin.webp')
kimzz.sendMessage(from, { sticker: kimzzStikRep }, { quoted: m })
}
const kimzzOwner = () => {
let kimzzStikRep = fs.readFileSync('./audio/owner.webp')
kimzz.sendMessage(from, { sticker: kimzzStikRep }, { quoted: m })
}
const kimzzGroup = () => {
let kimzzStikRep = fs.readFileSync('./audio/group.webp')
kimzz.sendMessage(from, { sticker: kimzzStikRep }, { quoted: m })
}
const kimzzPrivate = () => {
let kimzzStikRep = fs.readFileSync('./audio/private.webp')
kimzz.sendMessage(from, { sticker: kimzzStikRep }, { quoted: m })
}	
	
try {
ppuser = await kimzz.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)

const generateProfilePicture = async(buffer) => {
const jimp_1 = await Jimp.read(buffer);
const resz = jimp_1.getWidth() > jimp_1.getHeight() ? jimp_1.resize(550, Jimp.AUTO) : jimp_1.resize(Jimp.AUTO, 650)
const jimp_2 = await Jimp.read(await resz.getBufferAsync(Jimp.MIME_JPEG));
return {
img: await resz.getBufferAsync(Jimp.MIME_JPEG)
}
}
// enc fitur
async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `Kimzz offc`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}

// generate password
function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
} 
const cap = 'KIMZZ MD'
const kim = { 
key: {
fromMe: [], 
participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "0@s.whatsapp.net" } : {}) 
},

'message': {
	"interactiveMessage": {
						"header": {
						
							"hasMediaAttachment": [],
							"jpegThumbnail": logo,
													},
						"nativeFlowMessage": {
							"buttons": [
								{
									"name": "review_and_pay",
									"buttonParamsJson": "{\"currency\":\"MYR\",\"external_payment_configurations\":[{\"uri\":\"\",\"type\":\"payment_instruction\",\"payment_instruction\":\"hey ini test\"}],\"payment_configuration\":\"\",\"payment_type\":\"\",\"total_amount\":{\"value\":2500000,\"offset\":100},\"reference_id\":\"4MX98934S0D\",\"type\":\"physical-goods\",\"order\":{\"status\":\"pending\",\"description\":\"\",\"subtotal\":{\"value\":2500000,\"offset\":100},\"items\":[{\"retailer_id\":\"6348642505244872\",\"product_id\":\"6348642505244872\",\"name\":\"KIMZZ OFFICIAL\",\"amount\":{\"value\":2500000,\"offset\":100},\"quantity\":1}]}}"
								}
							]
			}
}}}
// reply
const reply = (teks) => {
kimzz.sendMessage(m.chat, { text: teks, contextInfo:{"externalAdReply": {"title": 'Kimzz Store | Bebas Share',"body": `Hai kak 👋 ${pushname}`, "previewType": "PHOTO","thumbnail": logo, "sourceUrl": `https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK`}}}, { quoted: m })}

// newreply 
const newReply = (teks) => {
kimzz.sendMessage(m.chat, { text: teks, contextInfo:{"externalAdReply": {"title": 'Kimzz Store | Bebas Share',"body": `Hai kak 👋 ${pushname}`, "previewType": "PHOTO","thumbnail": logo, "sourceUrl": `https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK`}}}, { quoted: m })}

const vcard = 'BEGIN:VCARD\n' // metadata of the contact card
            + 'VERSION:3.0\n' 
            + 'FN:KIMZZ\n' // full name
            + 'ORG:KIMZZ;\n' // the organization of the contact
            + 'TEL;type=CELL;type=VOICE;waid=60146351257:+60 14 635 1257\n' // WhatsApp ID + phone number
            + 'END:VCARD'

switch (command) {
case 'owner':
kimzz.sendMessage(from,
{ 
contacts: { 
displayName: 'Ini Adalah Contact Pembuat Bot Kak', 
contacts: [{ vcard }] 
}
}
)
kimzz.sendMessage(from, {text : 'Tuh Nombor Owner Kimzz Jangan Spam'}, {quoted : m})       
break   
case "help": case "menu": {
await loading()
const quotedkimzz = galau[Math.floor(Math.random() * galau.length)]	
let anu = `𝘐 𝘈𝘮 𝘈𝘯 𝘈𝘶𝘵𝘰𝘮𝘢𝘵𝘦𝘥 𝘚𝘺𝘴𝘵𝘦𝘮 (𝘞𝘩𝘢𝘵𝘴𝘢𝘱𝘱 𝘉𝘰𝘵) 𝘛𝘩𝘢𝘵 𝘊𝘢𝘯 𝘏𝘦𝘭𝘱 𝘛𝘰 𝘋𝘰 𝘚𝘰𝘮𝘦𝘵𝘩𝘪𝘯𝘨, 𝘚𝘦𝘢𝘳𝘤𝘩 𝘈𝘯𝘥 𝘎𝘦𝘵 𝘋𝘢𝘵𝘢 , 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯 𝘖𝘯𝘭𝘺 𝘛𝘩𝘳𝘰𝘶𝘨𝘩 𝘞𝘩𝘢𝘵𝘴𝘢𝘱𝘱.

乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Ram : ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *K A T A - R A N D O M*

${quotedkimzz}

乂 *L I S T - M E N U*

☍ ${prefix}allmenu
☍ ${prefix}apimenu
☍ ${prefix}aimenu
☍ ${prefix}vpsmenu
☍ ${prefix}othermenu
☍ ${prefix}toolsmenu
☍ ${prefix}downloadmenu
☍ ${prefix}makermenu
☍ ${prefix}ownermenu
☍ ${prefix}textpromenu
☍ ${prefix}searchmenu
☍ ${prefix}islammenu
☍ ${prefix}stalkmenu
☍ ${prefix}groupmenu
☍ ${prefix}cloudflare
☍ ${prefix}capikey

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "apimenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *A P I - M E N U*

☍ ${prefix}addpremium
☍ ${prefix}delpremium
☍ ${prefix}gantiapikey
☍ ${prefix}resetlimit
☍ ${prefix}gantiusername
☍ ${prefix}resetall
☍ ${prefix}deleteuser
☍ ${prefix}listuser

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "vpsmenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *L I N O D E - M E N U*

☍ ${prefix}resetpassword
☍ ${prefix}deletelinode
☍ ${prefix}listlinode
☍ ${prefix}onlinode
☍ ${prefix}offlinode
☍ ${prefix}rebootlinode
☍ ${prefix}rebuildlinode
☍ ${prefix}sisalinode
☍ ${prefix}saldolinode
☍ ${prefix}cekvps
☍ ${prefix}linode1gb
☍ ${prefix}linode2gb
☍ ${prefix}linode4gb
☍ ${prefix}linode8gb
☍ ${prefix}linode16gb

乂 *D O - M E N U*

☍ ${prefix}deldroplet
☍ ${prefix}sendvps
☍ ${prefix}ceksaldodo
☍ ${prefix}listdroplet
☍ ${prefix}cekdroplet
☍ ${prefix}turnoff
☍ ${prefix}turnon
☍ ${prefix}sisadroplet
☍ ${prefix}rebuild
☍ ${prefix}restartvps
☍ ${prefix}vps1g1c
☍ ${prefix}vps2g1c
☍ ${prefix}vps4g2c
☍ ${prefix}vps8g4c

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "aimenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *A I - M E N U*

☍ ${prefix}ai
☍ ${prefix}ai2
☍ ${prefix}chatgpt3
☍ ${prefix}chatgpt4
☍ ${prefix}bing
☍ ${prefix}text2image

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "othermenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *O T H E R - M E N U*

☍ ${prefix}larangan
☍ ${prefix}owner
☍ ${prefix}addpm2
☍ ${prefix}delpm2
☍ ${prefix}sticker
☍ ${prefix}smeme
☍ ${prefix}toonce
☍ ${prefix}toimg

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "cloudflare": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *C L O U D F L A R E*

☍ ${prefix}email
☍ ${prefix}listemail
☍ ${prefix}delemail
☍ ${prefix}listdomain
☍ ${prefix}addgc
☍ ${prefix}delgc

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "toolsmenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *T O O L S - M E N U*

☍ ${prefix}tts
☍ ${prefix}ssweb
☍ ${prefix}ebase
☍ ${prefix}debase
☍ ${prefix}ebinary
☍ ${prefix}debinary
☍ ${prefix}styletext
☍ ${prefix}createmail
☍ ${prefix}inboxmail
☍ ${prefix}tinyurl
☍ ${prefix}bittly

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "searchmenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *S E A R C H - M E N U*

☍ ${prefix}subfinder
☍ ${prefix}cekip
☍ ${prefix}cuaca
☍ ${prefix}getcase
☍ ${prefix}cekmyip
☍ ${prefix}wikipedia
☍ ${prefix}yts
☍ ${prefix}cloudsearch
☍ ${prefix}spotifysearch
☍ ${prefix}whois
☍ ${prefix}get
☍ ${prefix}translate
☍ ${prefix}simsimi

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "downloadmenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *D O W N L O A D - M E N U*

☍ ${prefix}ytmp3
☍ ${prefix}ytmp4
☍ ${prefix}tiktoknowm
☍ ${prefix}tiktokaudio
☍ ${prefix}soundcloud
☍ ${prefix}pixivdown
☍ ${prefix}sfilemobile
☍ ${prefix}pinterest
☍ ${prefix}stickerpack
☍ ${prefix}mediafire
☍ ${prefix}igdl
☍ ${prefix}igdl2
☍ ${prefix}fbdl
☍ ${prefix}twitter
☍ ${prefix}spotify

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "makermenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *M A K E R - M E N U*

☍ ${prefix}remini
☍ ${prefix}hdr
☍ ${prefix}hd
☍ ${prefix}hdv2
☍ ${prefix}reminiv2
☍ ${prefix}jadianime

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "textpromenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *T E X T P R O - M E N U*

☍ ${prefix}pornhub
☍ ${prefix}space
☍ ${prefix}neondevil
☍ ${prefix}marvelstudio

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "islammenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *I S L A M - M E N U*

☍ ${prefix}alquranaudio
☍ ${prefix}searchsurah
☍ ${prefix}asmaulhusna
☍ ${prefix}listsurah
☍ ${prefix}kisahnabi
☍ ${prefix}doaharian

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "groupmenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *G R O U P - M E N U*

☍ ${prefix}welcome
☍ ${prefix}hidetag
☍ ${prefix}tagall
☍ ${prefix}promote
☍ ${prefix}demote
☍ ${prefix}kick

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "ownermenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *O W N E R - M E N U*

☍ ${prefix}enc
☍ ${prefix}bcgc
☍ ${prefix}postgc
☍ ${prefix}delsampah
☍ ${prefix}addprem
☍ ${prefix}delprem
☍ ${prefix}addscammer
☍ ${prefix}delscammer
☍ ${prefix}listprem
☍ ${prefix}listscammer

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case "stalkmenu": {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *S T A L K - M E N U*

☍ ${prefix}ttstalk
☍ ${prefix}ghstalk
☍ ${prefix}igstalk
☍ ${prefix}npminfo
☍ ${prefix}wattpadstalk

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break   
case 'allmenu': {
await loading()
let anu = `乂 *I N F O - U S E R*

☍ *Name* : ${pushname}
☍ *Number* : ${m.sender.split('@')[0]}
☍ *Status* : ${isCreator ? "Owner 👑️":"User"}
☍ *User* : ${isCreator ? 'Premium 👑' : 'Gratisan'}

乂 *I N F O - B O T*

☍ Name : ${global.namaBot}
☍ Creator : ${global.namaCreator}
☍ Prefix : ( ${prefix} )
☍ Versi Script : *^1.1.1*
☍ Mode : ${kimzz.public ? 'Public-Mode 👥' : 'Self-Mode 👤'}
☍ Platform : ${os.platform()}
☍ Runtime : ${runtime(process.uptime())}
☍ Running : Cloudflare-page
☍ Language : Javascript
☍ Version Baileys : *^4.3.2*
☍ Total Fitur : ${totalFitur()}

乂 *O T H E R - M E N U*

☍ ${prefix}larangan
☍ ${prefix}owner
☍ ${prefix}addpm2
☍ ${prefix}delpm2
☍ ${prefix}sticker
☍ ${prefix}smeme
☍ ${prefix}toonce
☍ ${prefix}toimg

乂 *O W N E R - M E N U*

☍ ${prefix}enc
☍ ${prefix}bcgc
☍ ${prefix}postgc
☍ ${prefix}delsampah
☍ ${prefix}addprem
☍ ${prefix}delprem
☍ ${prefix}addscammer
☍ ${prefix}delscammer
☍ ${prefix}listprem
☍ ${prefix}listscammer

乂 *G R O U P - M E N U*

☍ ${prefix}welcome
☍ ${prefix}hidetag
☍ ${prefix}tagall
☍ ${prefix}promote
☍ ${prefix}demote
☍ ${prefix}kick

乂 *A P I - M E N U*

☍ ${prefix}addpremium
☍ ${prefix}delpremium
☍ ${prefix}resetlimit
☍ ${prefix}resetall
☍ ${prefix}deleteuser
☍ ${prefix}listuser
☍ ${prefix}gantiapikey
☍ ${prefix}gantiusername

乂 *C L O U D F L A R E*

☍ ${prefix}email
☍ ${prefix}listemail
☍ ${prefix}delemail
☍ ${prefix}listdomain
☍ ${prefix}addgc
☍ ${prefix}delgc

乂 *L I N O D E - M E N U*

☍ ${prefix}resetpassword
☍ ${prefix}deletelinode
☍ ${prefix}listlinode
☍ ${prefix}onlinode
☍ ${prefix}offlinode
☍ ${prefix}rebootlinode
☍ ${prefix}rebuildlinode
☍ ${prefix}sisalinode
☍ ${prefix}saldolinode
☍ ${prefix}cekvps
☍ ${prefix}linode1gb
☍ ${prefix}linode2gb
☍ ${prefix}linode4gb
☍ ${prefix}linode8gb
☍ ${prefix}linode16gb

乂 *D O - M E N U*

☍ ${prefix}deldroplet
☍ ${prefix}sendvps
☍ ${prefix}ceksaldodo
☍ ${prefix}listdroplet
☍ ${prefix}cekdroplet
☍ ${prefix}turnoff
☍ ${prefix}turnon
☍ ${prefix}sisadroplet
☍ ${prefix}rebuild
☍ ${prefix}restartvps
☍ ${prefix}vps1g1c
☍ ${prefix}vps2g1c
☍ ${prefix}vps4g2c
☍ ${prefix}vps8g4c

乂 *S E A R C H - M E N U*

☍ ${prefix}subfinder
☍ ${prefix}cekip
☍ ${prefix}cuaca
☍ ${prefix}getcase
☍ ${prefix}cekmyip
☍ ${prefix}wikipedia
☍ ${prefix}yts
☍ ${prefix}cloudsearch
☍ ${prefix}spotifysearch
☍ ${prefix}whois
☍ ${prefix}get
☍ ${prefix}translate
☍ ${prefix}simsimi

乂 *S T A L K - M E N U*

☍ ${prefix}ttstalk
☍ ${prefix}ghstalk
☍ ${prefix}igstalk
☍ ${prefix}npminfo
☍ ${prefix}wattpadstalk

乂 *D O W N L O A D - M E N U*

☍ ${prefix}ytmp3
☍ ${prefix}ytmp4
☍ ${prefix}tiktoknowm
☍ ${prefix}tiktokaudio
☍ ${prefix}soundcloud
☍ ${prefix}pixivdown
☍ ${prefix}sfilemobile
☍ ${prefix}pinterest
☍ ${prefix}stickerpack
☍ ${prefix}mediafire
☍ ${prefix}igdl
☍ ${prefix}igdl2
☍ ${prefix}fbdl
☍ ${prefix}twitter
☍ ${prefix}spotify

乂 *T E X T P R O - M E N U*

☍ ${prefix}pornhub
☍ ${prefix}space
☍ ${prefix}neondevil
☍ ${prefix}marvelstudio

乂 *M A K E R - M E N U*

☍ ${prefix}remini
☍ ${prefix}hdr
☍ ${prefix}hd
☍ ${prefix}hdv2
☍ ${prefix}reminiv2
☍ ${prefix}jadianime

乂 *A I - M E N U*

☍ ${prefix}ai
☍ ${prefix}ai2
☍ ${prefix}chatgpt3
☍ ${prefix}chatgpt4
☍ ${prefix}bing
☍ ${prefix}text2image

乂 *T O O L S - M E N U*

☍ ${prefix}tts
☍ ${prefix}ssweb
☍ ${prefix}ebase
☍ ${prefix}debase
☍ ${prefix}ebinary
☍ ${prefix}debinary
☍ ${prefix}styletext
☍ ${prefix}createmail
☍ ${prefix}inboxmail
☍ ${prefix}tinyurl
☍ ${prefix}bittly

乂 *I S L A M - M E N U*

☍ ${prefix}alquranaudio
☍ ${prefix}searchsurah
☍ ${prefix}asmaulhusna
☍ ${prefix}listsurah
☍ ${prefix}kisahnabi
☍ ${prefix}doaharian

乂 *T H A N K S - T O*

☍ _kimzzstore_  (ʙᴀsᴇ)  
☍ _kimzzoffc_  (ᴀᴘɪ)
☍ _WhiskeySockets_  (ʙᴀɪʟᴇʏs)`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   kimzz.sendMessage(m.chat, { audio: fs.readFileSync('./audio/seram.mp3'), mimetype: 'audio/mp4', ptt: true})
}
break
case "listdomain":{
if (!jangan) return;
let anu = `▭▬▭( *LIST DOMAIN* )▭▬▭

❏ Domain Active : 25
❏ Domain Proxied : False
❏ Domain Security : True
❏ Auto Block Ip : True

☍ ${prefix}cd1 kimzzpanel.cfd
☍ ${prefix}cd2 panellstore.net
☍ ${prefix}cd3 panellstore.icu
☍ ${prefix}cd4 panellstore.xyz
☍ ${prefix}cd5 panelsaya.com
☍ ${prefix}cd6 kimzzpanel.xyz
☍ ${prefix}cd7 sanzz-hosting.my.id
☍ ${prefix}cd8 sanzz-vipp.my.id
☍ ${prefix}cd9 firmanhost.my.id
☍ ${prefix}cd10 jasapanelzku.xyz
☍ ${prefix}cd11 garudanetwork.my.id
☍ ${prefix}cd12 panellme.biz.id
☍ ${prefix}cd13 api.kimzzoffc.me
☍ ${prefix}cd14 kimzzhosting.live
☍ ${prefix}cd15 kimzz-hosting.tech
☍ ${prefix}cd16 kimzzstore.tech
☍ ${prefix}cd17 panelstore.icu
☍ ${prefix}cd18 website-ku.software
☍ ${prefix}cd19 panellshop.biz.id
☍ ${prefix}cd20 panellshop.my.id
☍ ${prefix}cd21 paneellkuu.my.id
☍ ${prefix}cd22 sanzz-xd.com
☍ ${prefix}cd23 cpanell-net.biz.id
☍ ${prefix}cd24 pedia-panel.biz.id
☍ ${prefix}cd25 paneldigital.my.id
☍ ${prefix}cd26 panell-net.my.id
☍ ${prefix}cd27 panelelite.biz.id
☍ ${prefix}cd28 panell-tech.biz.id
☍ ${prefix}cd29 sanzzstore.tech

▬▭▬▭▬▭▬▭▬▭▬▭▬`
kimzz.sendMessage(m.chat, {
    text: anu,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Creator-Kimzz",
        thumbnailUrl: "https://telegra.ph/file/11a0f6b2f39c9a6023b25.jpg",
        sourceUrl: "https://chat.whatsapp.com/HL4eNamdh4u6pBnpHtBcqK",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
}
break
case  'addgc':{
await loading()
if (!isGroup) return kimzzGroup()      
if (!isCreator) return kimzzOwner()
pler.push(m.chat)
fs.writeFileSync('./database/idgrup.json', JSON.stringify(pler))
newReply('Sukses the group can create a domain')
}
break
case  'delgc':{
await loading()
if (!isGroup) return kimzzGroup()     
if (!isCreator) return kimzzOwner()
var ini = pler.indexOf(m.chat)
pler.splice(ini, 1)
fs.writeFileSync('./database/idgrup.json', JSON.stringify(pler))
newReply('the group can no longer access the domain')     
} 
break
case "larangan": {
newReply(`*Dilarang Membuat Subdomain Untuk Cpanel Jika Diketahui Oleh Admin Buyer Akan Dikick Dari Group Create Subdomain Tanpa Di Reff Uang Nya*`)
}
break
case  'cd1': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "9f10aab20d0bde47c01a6f3a0781ccec";
               let apitoken = "YhjPIctmZUUcwrtLD78ynWo2uNt7AbOmjOKMnL";
               let tld = "kimzzpanel.cfd";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd1 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
}); }
break
case  'cd2': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "75743078ed2f835ede897fc2187122bd";
               let apitoken = "PrrlP5uUP4xCCo2GQnFWZ6jklJEuIloNx1L_wihX";
               let tld = "panellstore.net";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd2 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd3': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "b2dab95fa93b9957f47ef84e1bc9558f";
               let apitoken = "PrrlP5uUP4xCCo2GQnFWZ6jklJEuIloNx1L_wihX";
               let tld = "panellstore.icu";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd3 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd4': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "26b6ce099dc3d48e0b491a294786c68b";
               let apitoken = "PrrlP5uUP4xCCo2GQnFWZ6jklJEuIloNx1L_wihX";
               let tld = "panellstore.xyz";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd4 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd5': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "52e13cf0d14ff96b5588c24ee518f6a7";
               let apitoken = "NrLYJWce-9G9ziALW_vfm0EJdpNruskyc0GqxbJl";
               let tld = "panelsaya.com";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd5 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd6': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "aafc2cc3e206a80c45892c5cb4e4951e";
               let apitoken = "s6l2DTtHkIppljxnkS_vSguQ7X8k0Z8jiSXqzDQF";
               let tld = "kimzzpanel.xyz";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd6 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd7': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "13979fb66aa84de6b69d0515e254a2d6";
               let apitoken = "mpvwsktLw_FQcAiRiLnA0wed-Q6nDiI_OfM8FXpK";
               let tld = "sanzz-hosting.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd7 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd8': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "e7c1e580c22c5aa69b97fdc8519648db";
               let apitoken = "TeRoNgYC8ImYxL8sRjSDk308Gzkm5rrnUMwSE852";
               let tld = "sanzz-vipp.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd8 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd9': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "32c78399ed3db2d582b8ce932cb73742";
               let apitoken = "xYfYZuvNWW1opHf-vvqbyyeDGmwJEHbRZxcB2B9B";
               let tld = "firmanhost.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd9 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd10': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "39b4ead5856fa13269c4477f949c7903";
               let apitoken = "Rq3xvK3lSsBIMbUqgS3GGc9VokH3DlLWA4o5ZD9Y";
               let tld = "jasapanelzku.xyz";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd10 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd11': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "f70a6a6a0f9df1c948c2b0b23df83bb7";
               let apitoken = "MANDcbwasWd_x-ei71U-AGPeM6TBcfPnhD5XTE5a";
               let tld = "garudanetwork.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd11 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd12': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "2886098d602f0b0618460c08846f1de8";
               let apitoken = "mZk01DJ73VXXLkr877fClU8IcBvWSuTJ-yEuiY82";
               let tld = "panellme.biz.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd12 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd13': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "e789d0a15183e89b7d0fd7e8a1bab2d1";
               let apitoken = "_kD3NRE-DPufQjPpEdQuZ_JF3HfoZ3sOt75-PZ-y";
               let tld = "kimzzoffc.me";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd13 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd14': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "b3ffd68d06409e82f30e5283d9af6031";
               let apitoken = "ppAa1XbDOMmKcs_VP06EesazjWcBYD1y9IZd6mt_";
               let tld = "kimzzhosting.live";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd14 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd15': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "8c7ab78e2444a505018e333ebd8e967f";
               let apitoken = "l4FOZgUJCyRFakhqeuBQTeubbFnGiO_MY8eR9lz_";
               let tld = "kimzz-hosting.tech";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd15 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd16': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "412cdd34358a11e46a4f875d97a34309";
               let apitoken = "lKBYaRoqbOqm0jP4uAW3teYpbOa2zLGuLwPP3G2y";
               let tld = "kimzzstore.tech";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd16 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd17': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "9152448b8218be793fec13a268f512d9";
               let apitoken = "6A0Eh2j-iqt1oI-ODYrm0A7oV39IKhD_lH3gbVAT";
               let tld = "panelstore.icu";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd17 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break
case  'cd18': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "0a12d3c013ac3d25f54ee4f0afc81c51";
               let apitoken = "rEiPKZ14T15Z2F5AoI1uLAW387NaWxZnWZGrUI94";
               let tld = "website-ku.software";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return newReply("PENGGUNAAN .cd18 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return newReply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return newReply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
case  'cd19': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "5e9c879001b63885301e77f48c3d7e58";
               let apitoken = "yphLnXT8CL6t6NO7HozsTyqCO6_CIgbb8I7Nudwz";
               let tld = "panellshop.biz.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd19 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
case  'cd20': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "fa2790178cc13b4b23425274cf2540a3";
               let apitoken = "DSRw23oEmsVU-7OzObRdYnJUVQy8vOed0otx39IO";
               let tld = "panellshop.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd20 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
case  'cd21': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "67608e842ce5652108ac3758dce69c20";
               let apitoken = "VgYsYWU7xKK4LG-3V8WaaYx0gcWN-DKI2Vk9npUf";
               let tld = "paneellkuu.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd21 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case  'cd22': {
if (!isCreator) return kimzzOwner()
pler.push(m.chat)
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "d9eb243bf22ba449feae21c2a80fffba";
               let apitoken = "-jl34ivqVQWjaPVDA_zi12QHc07vwCZ85CDDZoSd";
               let tld = "sanzz-xd.com";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd22 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case  'cd23': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "016ec3d7a8a5f0c3d2c56ee1980f3f2a";
               let apitoken = "vzZ6L5IdH6-RJSv_hPhrONne9sXp6NJ5uloK1PI-";
               let tld = "cpanell-net.biz.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd23 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case  'cd24': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "313ff58a12c1d8c928581ec721ca3685";
               let apitoken = "81QOv4j7OQi1st2iT_lW3hy22nKKhkcj1JA2kjn9";
               let tld = "pedia-panel.biz.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd24 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case  'cd25': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "20fa5bf6edca2ab185be760c15ada53e";
               let apitoken = "fHm1j22HLHMcW6zGGr-W_pL8O6__tl5XTRbsSLTd";
               let tld = "paneldigital.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd25 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
          break
           case  'cd26': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "217d5caa4dd9adab25e69bdfacd6294b";
               let apitoken = "TO1QV0p5WBVkBJpgGIdlcEN0yR0fp6e2kM10-naf";
               let tld = "panell-net.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd26 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); } 
           break
           case  'cd27': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "3e6ec90ce998dcbc24a78fcfc6ea4c07";
               let apitoken = "Nn2b3QfE91c1OG9SplHkyFZcxix3F6C-bXlrWKxj";
               let tld = "panelelite.biz.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd27 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case  'cd28': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "db7ee82aaf8f9ac8f61a26b64809f224";
               let apitoken = "3XwQzs3kEuysArdJtW1aZ2ujE0stOEFycAlvsjQ4";
               let tld = "panell-tech.biz.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd28 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           case  'cd29': {
    if (!jangan) return;
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "c6a11d5aac1db79fb3667d2b6213bae9";
               let apitoken = "QK0fQI4p3bPYtxi7wm3JjLToozOsSH4xDugn-g7Z";
               let tld = "sanzzstore.tech";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                 { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .cd29 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) newReply(`┏━━━━━━━━━━━━━━━━━━━
┣ Ip = ${e['ip']}
┗━━━━━━━━━━━━━━━━━━━
┣ Username = ${e['name']}
┗━━━━━━━━━━━━━━━━━━━
┣ crate by = ${global.namaBot}
┗━━━━━━━━━━━━━━━━━━━`);
             else newReply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
// fitur create by kimzz
break
case 'subfinder':{
kimzzWait()
if (args.length == 0) return newReply(`Example: ${prefix + command} kimzzpanel.xyz`)
subdomain = args[0]
fetchJson(`https://api.kimzzoffc.me/api/subfinder?host=${subdomain}&apikey=kimzzstore`).then(res => {
var listsubdomain = [];
for (let x of res.result) {
listsubdomain.push(x)
}
var teks = `*List Subdomain ${subdomain}*\n\n`
for (let i of listsubdomain) {
teks += `*Name :* _${i.domain}_\n*Dns :* _${i.dns}_\n*Proxy :* _❌_\n\n`
}
newReply(teks)
})
}      
break
case 'getcase':
try{
if (!isCreator) return kimzzOwner()
if (!q) return newReply(`Example: ${prefix + command} antilink`)
let nana = await getCase(q)
newReply(nana)
} catch(err){
console.log(err)
newReply(`Case ${q} tidak di temukan`)
}
break
case 'totalfitur': {  
newReply(`Total Bot Features Are ${totalFitur()}`)
}
// add pm2 fitur
break
case 'addpm2':
  if (!isCreator) return kimzzOwner()

  if (args.length !== 1) {
    return newReply('Format penggunaan salah. Contoh: !addip <url atau ip>');
  }
  
  const input = args[0];

  function resolveToIp(input) {
    return new Promise((resolve, reject) => {
      if (isValidIp(input)) {
        resolve(input);
      } else {
        dns.resolve4(input, (err, addresses) => {
          if (err) {
            reject(err);
          } else {
            resolve(addresses[0]);
          }
        });
      }
    });
  }

  function isValidIp(input) {
    return /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(input);
  }
  
  resolveToIp(input)
    .then(ip => {
      const apiUrl = 'https://cekilhost.net/api/addcekil';

      axios.post(apiUrl, `ip=${ip}`)
        .then(response => {
          if (response.data.status === 'success') {
            const successMessage = `Berhasil Mendaftar pm2 dengan IP/URL: ${ip}`;
            newReply(successMessage);

            //Mengirim file cekil.json dari direktori
            let cekil = fs.readFileSync('./kimzz.json', 'utf-8');

            // Mengirim file cekil.json sebagai dokumen
            kimzz.sendMessage(m.chat, { document: Buffer.from(cekil), mimetype: 'application/json', fileName: 'kimzz.json' }, { quoted: m });
          } else {
            const errorMessage = 'Terjadi kesalahan: ' + response.data.message;
            newReply(errorMessage);
          }
        })
        .catch(error => {
          console.error(error);
          newReply('Terjadi kesalahan saat mengirim permintaan.');
        });
    })
    .catch(error => {
      console.error(error);
      newReply('Terjadi kesalahan saat melakukan DNS lookup atau input tidak valid.');
    });
  break
    case 'deleteip':
    if (!isCreator) return kimzzOwner()

    if (args.length !== 1) {
        return newReply('Format penggunaan salah. Contoh: !deleteip <ip>');
    }

    const ipToDelete = args[0];

    const deleteUrl = 'https://cekilhost.net/api/deletecekil';

    require('axios').post(deleteUrl, `ip=${ipToDelete}`)
        .then(response => {
            if (response.data.status === 'success') {
                const successMessage = `IP ${ipToDelete} berhasil dihapus.`;
                newReply(successMessage);
            } else {
                const errorMessage = 'Terjadi kesalahan: ' + response.data.message;
                newReply(errorMessage);
            }
        })
        .catch(error => {
            console.error(error);
            newReply('Terjadi kesalahan saat mengirim permintaan.');
        });
// fitur group
break
case 'listpremium': case 'listprem': {
teks = '*List Premium*\n\n'
for (let kimzzp of prem) {
teks += `- ${kimzzp}\n`
}
teks += `\n*Total : ${prem.length}*`
kimzz.sendMessage(m.chat, { text: teks.trim() }, 'extendedTextMessage', { quoted: m, contextInfo: { "mentionedJid": prem } })
}
break
case 'addprem':{
if (!isCreator) return kimzzOwner()
if (!args[0]) return reply(`Penggunaan ${prefix+command} Penggunaan :\n*#addprem* @tag waktu\n*#addprem* nomor waktu\n\nContoh : #addprem @tag 30d`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await kimzz.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Masukkan Nombor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
prem.push(prrkek)
fs.writeFileSync("./database/premium.json", JSON.stringify(prem))
reply(`Nombor ${prrkek} Telah Menjadi Premium!`)
}
break
case "delprem":{
if (!isCreator) return kimzzOwner()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 60146351257`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync("./database/premium.json", JSON.stringify(prem))
reply(`Nombor ${ya} Telah Di Hapus Premium!`)
}
break
case "welcome":{
if (!isCreator) return kimzzOwner()
if (!m.isGroup) return newReply(mess.OnlyGroup)
await loading()
if (args.length < 1) return newReply('ketik on untuk mengaktifkan\nketik off untuk menonaktifkan')
if (args[0] === "on") {
if (welcm) return newReply('Sudah Aktif')
wlcm.push(from)
var groupe = await kimzz.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
kimzz.sendMessage(from, {text: `Fitur Welcome Di Aktifkan Di Group Ini`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!welcm) return newReply('Sudah Non Aktif')
let off = wlcm.indexOf(from)
wlcm.splice(off, 1)
newReply('Sukses Mematikan Welcome  di group ini')
}
}
break
case 'kick': {
if (!m.isGroup) return kimzzGroup()
if (!isBotAdmins) return newReply('Bot Bukan Admin Cuy')
if (!isAdmins) return newReply('Lah Dikira Admin Group Kali')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await kimzz.groupParticipantsUpdate(from, [users], 'remove').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
}
break
case 'demote': {
if (!isCreator) return kimzzOwner()
if (!m.isGroup) return newReply('Buat Di Group Bodoh')
if (!isBotAdmins) return newReply('Bot Bukan Admin Cuy')
if (!isAdmins) return newReply('Lah Dikira Admin Group Kali')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await kimzz.groupParticipantsUpdate(from, [users], 'demote').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
}
break
case 'promote': {
if (!isCreator) return kimzzOwner()
if (!m.isGroup) return newReply('Buat Di Group Bodoh')
if (!isBotAdmins) return newReply('Bot Bukan Admin Cuy')
if (!isAdmins) return newReply('Lah Dikira Admin Group Kali')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await kimzz.groupParticipantsUpdate(from, [users], 'promote').then((res) => newReply(jsonformat(res))).catch((err) => newReply(jsonformat(err)))
}
break
case 'hidetag': {
if (!isGroup) return kimzzGroup()      
if (!isGroupAdmins) return kimzzAdmin()
if (!m.isGroup) return kimzzGroup
kimzz.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, { quoted:m })
}
break
case 'tagall': case 'infoall':{
if (!isGroup) return kimzzGroup()      
  if (!isGroupAdmins) kimzzAdmin()
  let tekss = `*PENGUMUMAN 📢*\n\n*Pesan : ${q ? q : 'Nothing'}*\n\n`
  for (let mem of participants) {
  tekss += `🌱 @${mem.id.split('@')[0]}\n`
  }
  tekss += `\n*Kimzz*`
  kimzz.sendMessage(m.chat, { text: tekss, mentions: participants.map(a => a.id) }, { quoted: m })  
}
break
                case 'cekip':{
                    if (args.length == 0) return newReply(`Example: ${prefix + command} ip anda`)
                    username = args[0]
                    ini_result = await fetchJson(`https://api.kimzzoffc.me/api/iplookup?query=${username}&apikey=kimzzstore`)
                    ini_result = ini_result.result
                    ini_txt = `Negara : ${ini_result.country}\n`
                    ini_txt += `city : ${ini_result.city}\n`
                    ini_txt += `latitud : ${ini_result.lat}\n`
                    ini_txt += `longtitud : ${ini_result.lon}\n`
                    ini_txt += `Time zone : ${ini_result.timezone}\n`
                    ini_txt += `isp : ${ini_result.isp}\n`
                    ini_txt += `currency : ${ini_result.currency}\n`
                    ini_txt += `asname : ${ini_result.asname}\n`
                    ini_txt += `proxy : ${ini_result.proxy}\n`
                    ini_txt += `mobile : ${ini_result.mobile}\n`
                    ini_txt += `hosting : ${ini_result.hosting}\n`
                    ini_txt += `ip andress : ${ini_result.query}\n`
                   newReply(ini_txt)
                }
break
                case 'wikipedia':{
                    if (args.length == 0) return newReply(`Example: ${prefix + command} ip anda`)
                    username = args[0]
                    ini_result = await fetchJson(`https://api.kimzzoffc.me/api/wikipedia?query=${username}&apikey=kimzzstore`)
                    ini_result = ini_result.result
                    ini_txt = `${ini_result.articles}`
                   newReply(ini_txt)
                }
break
case 'cuaca':{
if (!q) throw `_Contoh_\n${prefix+command} kuala lumpur`
let api_cuaca = '18d044eb8e1c06eaf7c5a27bb138694c'
let unit_cuaca = 'metric'
let nama_kota = q
let cuaca = await fetchJson(`http://api.openweathermap.org/data/2.5/weather?q=${nama_kota}&units=${unit_cuaca}&appid=${api_cuaca}`)
let text_cuaca =`*INFO CUACA*

*Nama:* ${cuaca.name + "," + cuaca.sys.country}
*Longitude:* ${cuaca.coord.lon}
*Latitude:* ${cuaca.coord.lat}
*Suhu:* ${cuaca.main.temp + " C"}
*Angin:* ${cuaca.wind.speed + " m/s"}
*Kelembaban:* ${cuaca.main.humidity + "%"}
*Cuaca:* ${cuaca.weather[0].main}
*Keterangan:* ${cuaca.weather[0].description}
*Udara:* ${cuaca.main.pressure + " HPa"}`
newReply(text_cuaca)   
}
break
       
        case 'cekmyip': {
        await loading()
                var http = require('http')
                http.get({
                    'host': 'api.ipify.org',
                    'port': 80,
                    'path': '/'
                }, function(resp) {
                    resp.on('data', function(ip) {
                        m.reply("🔎 My public IP address is: " + ip);
                    })
                })
            }
break
                case 'simsimi':{
                    if (args.length == 0) return newReply(`Example: ${prefix + command} kata`)
                    username = args[0]
                    ini_result = await fetchJson(`https://api.by.kimzzstore.tech/api/simsimi?kata=${username}&apikey=kimzzstore`)
                    ini_result = ini_result.result
                    ini_txt = `${ini_result.success}\n`
                   newReply(ini_txt)
                }
break
case 'translate':
if (!m.quoted && !text) return newReply(`Example: ${prefix + command} id good morning`)
lang = args[0]
args.shift()
let quo = m.quoted ? m.quoted.text ? m.quoted.text : q ? q : m.text : q ? q : m.text
get_result = await fetchJson(`https://api.kimzzoffc.me/api/translate?lang=${lang}&text=${quo}&apikey=kimzzstore`)
get_result = get_result.result
newReply(get_result)
break
case 'doaharian':{
await loading()
fetchJson(`https://api.kimzzoffc.me/api/islam/doaharian?apikey=kimzzstore`).then(res => {
var doaharian = [];
for (let x of res.result.data) {
doaharian.push(x)
}
var teks = `*List Doa Harian*\n\n`
for (let i of doaharian) {
teks += `*title :* ${i.title}\n*Arab :* ${i.arabic}\n*Melayu :* ${i.latin}\n*Maksud Ayat :* ${i.translation}\n\n`
}
newReply(teks)
})
}
// admin menu
break
case 'addpremium':{
if (!isCreator) return kimzzOwner()
if (args.length == 0) return newReply(`Example: ${prefix + command} username,expired`)
const custom = "custom"
const token = "Kimzz"
const [username, expired] = args[0].split(',');
if (!username || !expired) {
return newReply('Sila masukkan dua teks dengan "," separator, contoh: username,expired');
}
ini_result = await fetchJson(`https://api.kimzzoffc.me/api/addpremium?username=${username}&expired=${expired}d&customKey=${custom}&token=${token}`)
init_result = ini_result.result.result
ini_txt = `*_Berjaya Menambah Pengguna ${username} Kepada Premium Dengan Tempoh Masa Premium Selama ${expired}day_*\n\n`	
ini_txt += `☍ Username: ${init_result.user.username}\n`	
ini_txt += `☍ Limit: ${init_result.user.limit}\n`	
ini_txt += `☍ Login: https://api.kimzzoffc.me\n`	
ini_txt += `☍ Status Key: Premium User\n`
ini_txt += `☍ Expired: ${init_result.expirationDateTime}\n\n`
ini_txt += `  ❏  *INFORMATION*  ❏\n
❏ Jagalah keamanan Apikey Anda
❏ Dilarang menyebarkan Apikey
❏ Terima Kasih Telah Support Kami`
newReply(ini_txt)
}
break
case 'delpremium':{
if (!isCreator) return kimzzOwner()
if (args.length == 0) return newReply(`Example: ${prefix + command} username`)
username = args[0]
ini_result = await fetchJson(`https://api.by.kimzzstore.tech/api/delpremium?username=${username}&token=Kimzz`)
ini_txt = `*Berjaya Menghapus Pengguna ${username} Dari Premium*\n\n`
ini_txt += `*❏ Username: ${username}*\n`	
ini_txt += `*❏ Limit: 200*\n`
ini_txt += `*❏ Status Key: Free User*\n`
ini_txt += `*❏ Login: https://api.kimzzoffc.me*\n`
ini_txt += `*❏ Jam: ${jam}*\n`
ini_txt += `*❏ Tarikh: ${tanggal}*\n`		
newReply(ini_txt)
}
break
case 'gantiapikey':{
if (!isCreator) return kimzzOwner()
if (args.length == 0) return newReply(`Example: ${prefix + command} username,key`)
const token = "Kimzz"
const [username, key] = args[0].split(',');
if (!username || !key) {
return newReply('Sila masukkan dua teks dengan "," separator, contoh: username,key');
}
ini_result = await fetchJson(`https://api.kimzzoffc.me/api/gantiapikey?username=${username}&key=${key}&token=${token}`)
let ini_txt = `*Berhasil Menukar Apikey\n\n*`
ini_txt += `Username: ${username}\n`
ini_txt += `New Apikey: ${key}\n`
ini_txt += `Status: Premium`
newReply(ini_txt)
}
break
case 'ssweb': {
  if (args.length < 2) {
    return newReply(`Silahkan masukkan type nya\n\nf = full\nm = mobile\nd = dekstop\ni = ipad\n\ncontoh: .ssweb google.com f`);
  }

  const ini_link = args[0];
  const type = args[1].toLowerCase(); // Mengubah jenis menjadi huruf kecil untuk memastikan kesesuaian.

  let jenisTeks;

  switch (type) {
    case 'f':
      jenisTeks = 'full';
      break;
    case 'm':
      jenisTeks = 'mobile';
      break;
    case 'd':
      jenisTeks = 'desktop';
      break;
    case 'i':
      jenisTeks = 'ipad';
      break;
    default:
      return newReply(`Jenis tidak valid. Gunakan f, m, d, atau i. Contoh: .ssweb google.com f`);
  }

const ini_buffer = await getBuffer(`https://api.kimzzoffc.me/api/ssweb?type=${jenisTeks}&link=${ini_link}&apikey=kimzzstore`);
kimzz.sendMessage(from, { image: ini_buffer, caption: `done tuan 😁` }, { quoted: m });
}
break
case 'pornhub': {
if (args.length == 0) return newReply(`Example: ${prefix + command} kimzz store`)
const [text1, text2] = args[0].split('|');
if (!text1 || !text2) {
return newReply('Sila masukkan dua teks dengan "|" separator, contoh: text1|text2');
}
ini_buffer = await fetchJson(`https://api.kimzzoffc.me/api/textpro/pornhub?text=${text1}&text2=${text2}&apikey=kimzzstore`)
kimzz.sendMessage(from, { image: { url: ini_buffer.result  }, caption: `done tuan 😁` }, { quoted: m })
}
break
case 'space': {
if (args.length == 0) return newReply(`Example: ${prefix + command} text1|text2`)
const [text1, text2] = args[0].split('|');
if (!text1 || !text2) {
return newReply('Sila masukkan dua teks dengan "|" separator, contoh: text1|text2');
}
ini_buffer = await fetchJson(`https://api.kimzzoffc.me/api/textpro/space?text=${text1}&text2=${text2}&apikey=kimzzstore`)
kimzz.sendMessage(from, { image: { url: ini_buffer.result  }, caption: `done tuan 😁` }, { quoted: m })
}
break
case 'tinyurl':
if (args.length == 0) return newReply(`Example: ${prefix + command} api.kimzzoffc.me`)
ini_link = args[0]
get_result = await fetchJson(`https://api.kimzzoffc.me/api/linkshort/tinyurl?link=${ini_link}&apikey=kimzzstore`)
get_result = get_result.result
ini_txt = `_*Converter Link To Tinyurl*_\n\n`
ini_txt += `Normal: ${ini_link}\n`
ini_txt += `result: ${get_result}`
newReply(ini_txt)
break
case 'bittly':
if (args.length == 0) return newReply(`Example: ${prefix + command} api.kimzzoffc.me`)
ini_link = args[0]
get_result = await fetchJson(`https://api.kimzzoffc.me/api/linkshort/bitly?link=${ini_link}&apikey=kimzzstore`)
get_result = get_result.result
ini_txt = `_*Converter Link To Bittly*_\n\n`
ini_txt += `Created at: ${get_result.created_at}\n`
ini_txt += `id: ${get_result.id}\n`
ini_txt += `link: ${get_result.link}\n`
ini_txt += `long url: ${get_result.long_url}`
newReply(ini_txt)
break
case 'tiktoknowm':
if (args.length == 0) return newReply(`Example: ${prefix + command} https://www.tiktok.com/@wilianugrah1/video/7288308401669410053?is_from_webapp=1`)
ini_link = args[0]
get_result = await fetchJson(`https://api.kimzzoffc.me/api/tiktok2?url=${ini_link}&apikey=kimzzstore`)
kimzz.sendMessage(from, { video: { url: get_result.result.nowm }, caption: `${get_result.result.title}` }, { quoted: m })
break
case 'tiktokaudio':
if (args.length == 0) return newReply(`Example: ${prefix + command} https://www.tiktok.com/@wilianugrah1/video/7288308401669410053?is_from_webapp=1`)
ini_link = args[0]
get_result = await fetchJson(`https://api.kimzzoffc.me/api/tiktok2?url=${ini_link}&apikey=kimzzstore`)
kimzz.sendMessage(from, { audio: { url: get_result.result.audio }, mimetype: 'audio/mpeg' }, { quoted: m })
break
case 'tts':
if (args.length == 0) return newReply(`Example: ${prefix + command} hello`)
get_result = await fetchJson(`https://api.kimzzoffc.me/api/tts?text=${full_args}&lang=id-ID&apikey=kimzzstore`)
kimzz.sendMessage(from, { audio: { url: get_result.result }, mimetype: 'audio/mpeg', ptt: true }, { quoted: m })
break
case 'ytmp3': {
if (args.length == 0) return newReply(`Example: ${prefix + command} https://youtu.be/5C8yvJUVB-0`)
kimzzWait()
ini_link = args[0]
get_result = await fetchJson(`https://api.kimzzoffc.me/api/ytmp3?url=${ini_link}&apikey=kimzzstore`)
kimzz.sendMessage(from, { audio: { url: get_result.result.result }, mimetype: 'audio/mpeg' }, { quoted: m })
}
break
case 'ytmp4':
if (args.length == 0) return newReply(`Example: ${prefix + command} https://youtu.be/5C8yvJUVB-0`)
ini_link = args[0]
kimzzWait()
get_result = await fetchJson(`https://api.kimzzoffc.me/api/ytmp4?url=${ini_link}&apikey=kimzzstore`)
kimzz.sendMessage(from, { video: { url: get_result.result.result }, caption: `⭔ Title : ${get_result.result.title}\n\n⭔ Quality : ${get_result.result.quality}` }, { quoted: m })
break
case 'yts':
if (args.length == 0) return newReply(`Example: ${prefix + command} dj sad`)
try {
let search = await fetchJson(`https://api.kimzzoffc.me/api/ytsearch?query=${full_args}&apikey=kimzzstore`)
let teks = `YouTube Search\n\nResult From ${full_args}\n\n`
let no = 1
for (let i of search.video) {
teks += `⭔ No : ${no++}\n⭔ Type : ${i.type}\n⭔ Video ID : ${i.videoId}\n⭔ Title : ${i.title}\n⭔ Views : ${i.view}\n⭔ Duration : ${i.durationH}\n⭔ Author : ${i.authorName}\n⭔ Url : ${i.url}\n\n─────────────────\n\n`
                }
kimzz.sendMessage(from, { image: { url: search.video[0].thumbnail },  caption: teks }, { quoted: m })
} catch (error) {
console.error(error);
newReply(`Video: ${full_args} , Tidak Dapat Kami Jumpai`);
}
break
case 'alquranaudio':
if (args.length == 0) return newReply(`Example: ${prefix + command} 18/16`)
get_result = await fetchJson(`https://api.kimzzoffc.me/api/islam/alquran?query=${full_args}&apikey=kimzzstore`)
get_result = get_result.result.data
kimzz.sendMessage(from, { audio: { url: get_result.audio.primary }, mimetype: 'audio/mpeg', ptt: true }, { quoted: m })
break
case 'ebase':{
if (args.length == 0) return newReply(`Example: ${prefix + command} kimzz store`)
ini_result = await fetchJson(`https://api.kimzzoffc.me/api/ebase64?text=${full_args}&apikey=kimzzstore`)
ini_txt = `_*Converted Text To Ebase*_\n\n`
ini_txt += `Text:  ${full_args}\n`
ini_txt += `Result:  ${ini_result.result}\n`
newReply(ini_txt)
}
break
case 'debase':{
if (args.length == 0) return newReply(`Example: ${prefix + command} a2ltenogc3RvcmU=`)
ini_result = await fetchJson(`https://api.kimzzoffc.me/api/debase64?text=${full_args}&apikey=kimzzstore`)
ini_txt = `_*Converted Ebase To Text*_\n\n`
ini_txt += `Text:  ${full_args}\n`
ini_txt += `Result:  ${ini_result.result}\n`
newReply(ini_txt)
}
break
case 'remini':
case 'hd': {
if (!isMedia) return newReply("reply image")
let media = await kimzz.downloadAndSaveMediaMessage(quoted)
let anu = await TelegraPh(media)
kimzzWait()
kimzz.sendMessage(from, { image: { url: `https://api.kimzzoffc.me/api/remini?link=${anu}&apikey=kimzzstore` }, caption: mess.succes }, { quoted: m })
}
break
case 'capikey':{
get_result = await fetchJson(`https://api.kimzzoffc.me/api/checkapikey?apikey=kimzzstore`)
get_result = get_result.result
ini_txt = `_*Information Apikey*_\n\n`
ini_txt += `*username:*  ${get_result.username}\n`
ini_txt += `*Request Today:*  ${get_result.requestToday}\n`
ini_txt += `*Total Request:*  ${get_result.totalRequest}\n`	
ini_txt += `*Total Limit:*  ${get_result.limit}\n`
ini_txt += `*Admin:*  true\n`
ini_txt += `*Premium:*  ${get_result.premium}\n`
ini_txt += `*expired:*  ${get_result.expired}`
kimzz.sendMessage(from, { image: { url: `https://telegra.ph/file/039e2aab4f82d60c23220.jpg` }, caption: ini_txt }, { quoted: m })
}
break
case 'fbdl':
if (args.length == 0) return newReply(`Example: ${prefix + command} https://fb.watch/ma3TK4pU3C/`)
kimzzWait()
try {
get_result = await fetchJson(`https://api.kimzzoffc.me/api/fbdl?url=${full_args}&wtsid=rdr_0Ho2VpRtDhZpgQQKm&apikey=kimzzstore`)
get_result = get_result.result
let ini_hd = `*Berhasil download Video Dari Facebook*\n`
ini_hd += `*Quality:* HD`
kimzz.sendMessage(from, { video: { url: get_result.HD }, caption: ini_hd }, { quoted: m })
} catch (error) {
console.error(error);
newReply('Ralat semasa memproses permintaan.');
}
break
case 'igdl':
if (args.length == 0) return newReply(`Example: ${prefix + command} link video ig`)
kimzzWait()
try {
get_result = await fetchJson(`https://api.kimzzoffc.me/api/igdl?url=${full_args}&apikey=kimzzstore`)
get_result = get_result.result.data
kimzz.sendMessage(from, { video: { url: get_result.data.url }, caption: `done tuan 😁` }, { quoted: m })
} catch (error) {
console.error(error);
newReply('Ralat semasa memproses permintaan.');
}
break
case 'igdl2':
if (args.length == 0) return newReply(`Example: ${prefix + command} link video ig`)
kimzzWait()
get_result = await fetchJson(`https://api.kimzzoffc.me/api/igdl2?url=${full_args}&apikey=kimzzstore`)
get_result = get_result.result.data
kimzz.sendMessage(from, { video: { url: get_result.download_link }, caption: `done tuan 😁` }, { quoted: m })
break
case 'twitter':
if (args.length == 0) return newReply(`Example: ${prefix + command} link video twitter`)
kimzzWait()
try {
get_result = await fetchJson(`https://api.by.kimzzstore.tech/api/twitter?url=${full_args}&apikey=kimzzstore`)
kimzz.sendMessage(from, { video: { url: get_result.url }, caption: `done tuan 😁` }, { quoted: m })
} catch (error) {
console.error(error);
newReply('Ralat semasa memproses permintaan.');
}
break
case 'soundcloud': {
if (args.length == 0) return newReply(`Example: ${prefix + command} https://soundcloud.com/user-943750457/jang-ganggu-shine-of-black`)
get_result = await fetchJson(`https://api.kimzzoffc.me/api/scdl?url=${full_args}&apikey=kimzzstore`)
kimzzWait()
kimzz.sendMessage(from, { audio: { url: get_result.result.link }, mimetype: 'audio/mpeg', }, { quoted: m })
}
break
case 'spotify': {
if (args.length == 0) return newReply(`Example: ${prefix + command} https://open.spotify.com/track/3gcYAkN1HyV7QwfRKApIka`)
get_result = await fetchJson(`https://api.kimzzoffc.me/api/spotifydl?url=${full_args}&apikey=kimzzstore`)
kimzzWait()
kimzz.sendMessage(from, { audio: { url: get_result.result.url }, mimetype: 'audio/mpeg', }, { quoted: m })
}
break
case 'pixivdown':
if (args.length == 0) return newReply(`Example: ${prefix + command} 94216857`)
ini_buffer = await getBuffer(`https://api.kimzzoffc.me/api/pixiv?id=${full_args}&ext=.jpg&apikey=kimzzstore`)
kimzz.sendMessage(from, { image: ini_buffer }, { quoted: m })
break
case 'sfilemobile':
if (args.length == 0) return newReply(`Example: ${prefix + command} https://sfile.mobi/7lKFMNNrxYX`)
get_result = await fetchJson(`https://api.kimzzoffc.me/api/sfiledl?url=${full_args}&apikey=kimzzstore`)
get_result = get_result.result
kimzz.sendMessage(from, { document: { url: get_result.link }, mimetype: 'application/json', }, { quoted: m })
// cek database scammer
break
case 'addscammer': {
  if (!isCreator) return kimzzOwner()
  if (!args[0]) return m.reply(`Example ${prefix + command} johndoe|60123456789`);
  
  const input = text.split("|");
  if (input.length !== 2) return m.reply('Format yang benar adalah: username|nombor');
  
  const username = input[0].trim();
  const nombor = input[1].trim().replace(/[^0-9]/g, '');

  if (username.length === 0 || nombor.length === 0) {
    return m.reply('Username atau nomor tidak valid.');
  }

  // Periksa apakah nomor yang dimasukkan adalah nomor WhatsApp yang valid
  let ceknye = await kimzz.onWhatsApp(nombor + '@s.whatsapp.net');
  if (ceknye.length === 0) {
    return m.reply('Masukkan Nomor yang Valid dan Terdaftar di WhatsApp!!!');
  }
  scammer.push({ username, nombor });
  fs.writeFileSync('./database/database.json', JSON.stringify(scammer));

 newReply(`Username ${username} dengan Nombor: ${nombor} telah ditambahkan Di List Scammer!!!`);
}
break
case 'delscammer': {
  if (!isCreator) return kimzzOwner()
  if (!args[0]) return m.reply(`Penggunaan ${prefix + command} johndoe|6012345678`);

  const input = text.split("|");
  if (input.length !== 2) return m.reply('Format yang benar adalah: username|nombor');

  const username = input[0].trim();
  const nombor = input[1].trim().replace(/[^0-9]/g, '');

  if (username.length === 0 || nombor.length === 0) {
    return m.reply('Username atau nomor tidak valid.');
  }

  for (let i = 0; i < scammer.length; i++) {
    if (scammer[i].username === username && scammer[i].nombor === nombor) {
      scammer.splice(i, 1);
      fs.writeFileSync("./database/database.json", JSON.stringify(scammer));
      return m.reply(`Username @${username} dengan Nombor: ${nombor} telah dihapus dari list scammer!!!`);
    }
  }
  m.reply('Akun tersebut tidak ada dalam daftar premium.');
}
break
case 'listscammer': {
  if (!scammer.length) return m.reply('Daftar scammer kosong.');
  
  let scammerList = 'All List Scammer:\n\n';
  scammer.forEach((item, index) => {
    scammerList += `${index + 1}. ${item.username} (${item.nombor})\n`;
  });
  
  m.reply(scammerList);
}
break
case 'reminiv2':
case 'hdv2':
case 'hdr': {
if (!isCreator) return kimzzOwner()
if (!isMedia) return newReply("reply image")
let media = await kimzz.downloadAndSaveMediaMessage(quoted)
let anu = await TelegraPh(media)
kimzzWait()
kimzz.sendMessage(from, { image: { url: `https://api.kimzzoffc.me/api/remini2?link=${anu}&apikey=kimzzstore` }, caption: mess.succes }, { quoted: m })
}
// ai fitur
break
case 'jadianime': {
if (!isCreator) return kimzzOwner()
if (!isMedia) return newReply("reply image")
let media = await kimzz.downloadAndSaveMediaMessage(quoted)
let anu = await TelegraPh(media)
kimzzWait()
kimzz.sendMessage(from, { image: { url: `https://api.kimzzoffc.me/api/toanime?link=${anu}&apikey=kimzzstore` }, caption: mess.succes }, { quoted: m })
}
break
case 'text2image': {
if (args.length == 0) return newReply(`Example: ${prefix + command} yellow car with small boy`)
ini_buffer = await getBuffer(`https://api.kimzzoffc.me/api/text2image?query=${full_args}&apikey=kimzzstore`)
kimzz.sendMessage(from, { image: ini_buffer, caption: `*Status:* 200\n*Result:* Create By Openai` }, { quoted: m })
}
break
case 'chatgpt3':{
if (args.length == 0) return newReply(`Example: ${prefix + command} kata`)
ini_result = await fetchJson(`https://api.kimzzoffc.me/api/chatgpt?query=${full_args}&apikey=kimzzstore`)
let ini_txt = `*Content:* ${full_args}\n\n`
ini_txt += `${ini_result.result}`
newReply(ini_txt)
}
break
case 'chatgpt4':{
if (!text) return newReply(`Example: ${prefix + command} kata`)
ini_result = await fetchJson(`https://api.kimzzoffc.me/api/chatgpt4?text=${text}&apikey=kimzzstore`)
let ini_txt = `*Content:* ${text}\n\n`
ini_txt += `${ini_result.result}`
newReply(ini_txt)
}
break 
case 'ai':{
    if (!m.quoted && !text) return newReply(`Example: ${prefix + command} kata`);
    let quo = m.quoted ? m.quoted.text ? m.quoted.text : q ? q : m.text : q ? q : m.text;
    ini_result = await fetchJson(`https://api.kimzzoffc.me/api/blackbox?text=${quo}&apikey=kimzzstore`);
    let ini_txt = `*Content:* ${quo}\n\n${ini_result.result}`;
    newReply(ini_txt);
}
break
case 'bing':{
if (args.length == 0) return newReply(`Example: ${prefix + command} kata`)
ini_result = await fetchJson(`https://api.kimzzoffc.me/api/bing?text=${full_args}&apikey=kimzzstore`)
let ini_txt = `*Content:* ${full_args}\n\n`
ini_txt += `${ini_result.result}`
newReply(ini_txt)
}
break
case 'ai2':{
if (!text) return newReply(`Example: ${prefix + command} kata`)
ini_result = await fetchJson(`https://api.kimzzoffc.me/api/kimzzgpt?text=${text}&apikey=kimzzstore`)
let ini_txt = `*Content:* ${text}\n\n`
ini_txt += `${ini_result.result.message}`
newReply(ini_txt)
}
break
case 'cloudsearch': {
if (args.length == 0) return newReply(`Example: ${prefix + command} dj sad`)
let kimzz = await fetchJson(`https://api.kimzzoffc.me/api/soundcloudsearch?query=${full_args}&apikey=kimzzstore`)
let tek = `Sound Cloud Search\n\nResult From ${full_args}\n\n`
let noo = 1
for (let i of kimzz.result) {
tek += `⭔ No : ${noo++}\n⭔ Title : ${i.title}\n⭔ Artist : ${i.artist}\n⭔ Views : ${i.views}\n⭔ Release : ${i.release}\n⭔ Time : ${i.timestamp}\n⭔ Url : ${i.url}\n\n─────────────────\n\n`
}
newReply(tek)
}
break
case 'spotifysearch': {
if (args.length == 0) return newReply(`Example: ${prefix + command} aiman tino`)
let kimzz_store = await fetchJson(`https://api.kimzzoffc.me/api/spotify?query=${full_args}&apikey=kimzzstore`)
let tek = `Spotify Search\n\nResult From ${full_args}\n\n`
let noo = 1
for (let i of kimzz_store.result) {
tek += `⭔ No : ${noo++}\n⭔ Title : ${i.title}\n⭔ Artist : ${i.artist}\n⭔ Popularity : ${i.popularity}\n⭔ Duration : ${i.duration}\n⭔ Url : ${i.url}\n\n─────────────────\n\n`
}
newReply(tek)
}
break
case 'kisahnabi': {
if (args.length == 0) return newReply(`Example: ${prefix + command} Muhammad`)
nama_nabi = args[0]
get_result = await fetchJson(`https://api.kimzzoffc.me/api/islam/kisahnabi?query=${nama_nabi}&apikey=kimzzstore`)
get_result = get_result.result
let init_txt = `Name: ${get_result.name}\n`
init_txt += `Tahun Kelahiran: ${get_result.lahir}\n`
init_txt += `Umur: ${get_result.age}\n`
init_txt += `place: ${get_result.place}\n\n`
init_txt += `Story: ${get_result.story}`
newReply(init_txt)
}
break
case 'igstalk': {
if (args.length == 0) return newReply(`Example: ${prefix + command} kimzz.store`)
nama_ig = args[0]
get_result = await fetchJson(`https://api.kimzzoffc.me/api/stalkig?username=${nama_ig}&apikey=kimzzstore`)
get_result = get_result.result
let init_txt = `*Username:* ${get_result.username}\n`
init_txt += `*Full Name:* ${get_result.fullname}\n`
init_txt += `*Posts:* ${get_result.posts}\n`
init_txt += `*Followers:* ${get_result.followers}\n`
init_txt += `*Following:* ${get_result.following}\n`
init_txt += `*Bio:* ${get_result.bio}\n`
kimzz.sendMessage(from, { image: { url: get_result.photo_profile }, caption: init_txt }, { quoted: m })
}
break
case 'ttstalk': {
if (args.length == 0) return newReply(`Example: ${prefix + command} bulansutena`)
nama_tt = args[0]
get_result = await fetchJson(`https://api.kimzzoffc.me/api/tiktokstalk?query=${nama_tt}&apikey=${apikey}`)
get_result = get_result.result.result
let init_txt = `*Username:* ${get_result.users.username}\n`
init_txt += `*Nickname:* ${get_result.users.nickname}\n`
init_txt += `*Signature:* ${get_result.users.signature}\n`
init_txt += `*Verified:* ${get_result.users.verified}\n`
init_txt += `*Private Account:* ${get_result.users.privateAccount}\n`
init_txt += `*Followers:* ${get_result.stats.followerCount}\n`
init_txt += `*Following:* ${get_result.stats.followingCount}\n`
init_txt += `*Total Like:* ${get_result.stats.heartCount}\n`
init_txt += `*Total Video:* ${get_result.stats.videoCount}\n`
kimzz.sendMessage(from, { image: { url: get_result.users.avatarLarger }, caption: init_txt }, { quoted: m })
}
break
case 'npminfo': {
if (args.length == 0) return newReply(`Example: ${prefix + command} hxz-api`)
nama_npm = args[0]
get_result = await fetchJson(`https://api.kimzzoffc.me/api/stalknpm?query=${nama_npm}&apikey=${apikey}`)
get_result = get_result.result
let init_txt = `Name Package: ${get_result.name}\n`
init_txt += `Latest Version: ${get_result.dist-tags.latest}\n`
init_txt += `Repository: ${get_result.repository.url}\n`
init_txt += `Author: ${get_result.author.name}\n\n`
init_txt += `Readme: ${get_result.readme}\n`
newReply(init_txt)
}
break
case 'getfile': {
if (!isCreator) return kimzzOwner()
if (args.length < 1) return newReply(`Example: ${prefix + command} kimzz.json`);
let file = args[0]
let sesi = await fs.readFileSync(`./${file}`)
newReply('Tunggu Sebentar, Sedang mengambil file')		
kimzz.sendMessage(from, { document: sesi, mimetype: 'application/json', fileName: `${file}` }, { quoted: m })
}
break
case 'get': {
if (!isCreator) return kimzzOwner()
  if (args.length === 0) {
    return newReply(`Example: ${prefix + command} Param *URL* must start with https:// or http://`);
  }

  const url = args[0];

  if (!url.startsWith('https://') && !url.startsWith('http://')) {
    return newReply('URL must start with https:// or http://');
  }

  axios.get(url)
    .then(response => {
      const jsonData = response.data; // Data JSON dari URL

      // Lakukan sesuatu dengan data JSON ini, misalnya, mencetaknya atau memprosesnya.
      newReply(JSON.stringify(jsonData, null, 2)); // Menampilkan data JSON sebagai string terformat
    })
    .catch(error => {
      newReply(`Failed to fetch data: ${error.message}`);
    });
}
break
case 'whois': {
  if (args.length === 0) {
    return newReply(`Param *URL* must start with https:// or http://`);
  }

  const domain = args[0];

  try {
    const response = await fetch(`https://api.kimzzoffc.me/api/whois2?query=${domain}&apikey=${apikey}`);
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    
    const data = await response.json(); // Mengurai respons sebagai JSON
    ini_result = data.result;
    let init_txt = `*Whois ${domain}*\n\n`
    init_txt += `${ini_result}`
    newReply(init_txt);
  } catch (error) {
    console.error('Fetch error:', error);
    newReply(`Gagal Mendapatkan Data Whois Untuk Domain ${domain} ini`);
  }
}
break
case 'createmail': {
get_result = await fetchJson(`https://api.kimzzoffc.me/api/tempmail?apikey=${apikey}`)
get_result = get_result.result
newReply(get_result)
}
break
case 'inboxmail': {
  if (args.length == 0) return newReply(`Example: ${prefix + command} U2Vzc2lvbjrXt8c19WhFipPFSidsX7EY`);
  try {
    get_result = await fetchJson(`https://api.kimzzoffc.me/api/get-inbox-tempmail?id=${full_args}&apikey=${apikey}`);
    let init_txt = `Pesan Masuk Dari Email Id:\n${full_args}\n\n`;
    init_txt += `Daripada: ${get_result.result[0][0].fromAddr}\n`;
    init_txt += `Subject: ${get_result.result[0][0].headerSubject}\n\n`;
    init_txt += `Pesan: ${get_result.result[0][0].text}\n`;
    newReply(init_txt);
  } catch (error) {
    console.error('Fetch error:', error);
    newReply(`Tiada Pesan Yang Masuk Untuk Id Email Ini`);
  }
}
// bahagian tambahan
break
case 'ping': case 'botstatus': case 'statusbot': {
                const used = process.memoryUsage()
                const cpus = os.cpus().map(cpu => {
                    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
			        return cpu
                })
                const cpu = cpus.reduce((last, cpu, _, { length }) => {
                    last.total += cpu.total
                    last.speed += cpu.speed / length
                    last.times.user += cpu.times.user
                    last.times.nice += cpu.times.nice
                    last.times.sys += cpu.times.sys
                    last.times.idle += cpu.times.idle
                    last.times.irq += cpu.times.irq
                    return last
                }, {
                    speed: 0,
                    total: 0,
                    times: {
			            user: 0,
			            nice: 0,
			            sys: 0,
			            idle: 0,
			            irq: 0
                }
                })
                let timestamp = speed()
                let latensi = speed() - timestamp
                neww = performance.now()
                oldd = performance.now()
                respon = `Running Server : Clouflare Page
               
Response Speed ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
`.trim()
newReply(respon)
}
// fitur cvps linode
break;
case "deletelinode": {
  if (!isCreator) return m.reply('Maaf, command ini hanya untuk pemilik.');

  let linodeId = args[0];
  if (!linodeId) return m.reply('ID Linode belum diberikan.');

  let deleteLinode = async () => {
    try {
      let response = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      if (response.status === 204) {
        newReply('Linode berhasil dihapus.');
      } else {
        throw new Error('Gagal menghapus Linode.');
      }
    } catch (error) {
      console.error('Terjadi kesalahan saat menghapus Linode:', error);
      m.reply('Sukses Menghapus Linode.');
    }
  };

  deleteLinode();

break;
}
case "sisalinode": {
  if (!isCreator) return m.reply(mess.OnlyOwner);

  async function getLinodeInfo() {
    try {
      const response = await fetch('https://api.linode.com/v4/account', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`,
        },
      });

      if (response.ok) {
        const accountInfo = await response.json();
        const linodeLimit = accountInfo.data.active_promo?.total || 0;
        const linodesCount = accountInfo.data.active_promo?.remaining || 0;

        return {
          linodeLimit,
          remainingLinodes: linodesCount,
          totalLinodes: linodeLimit - linodesCount,
        };
      } else {
        throw new Error('Gagal mendapatkan data akun Linode.');
      }
    } catch (error) {
      throw error;
    }
  }

  // Definisikan fungsi untuk mengeksekusi kasus "sisalinode"
  async function sisalinodeHandler() {
    try {
      if (!isCreator) {
        return newReply('Lu Siapanya Gua Anjg');
      }

      const linodeInfo = await getLinodeInfo();
      m.reply(`*Sisa VPS Linode Yang Dapat Anda Buat: ${linodeInfo.remainingLinodes}*

*Total VPS Linode Yang Sudah Terbuat: ${linodeInfo.totalLinodes}*`);
    } catch (error) {
      m.reply(`Terjadi kesalahan: ${error.message}`);
    }
  }

  sisalinodeHandler();
}
break       
case "rebuildlinode": {
  if (!isCreator) return newReply(`Lu Siapanya Gua Anjg Gausah Nyuruh Nyuruh Gua Anjg`);

  let linodeId = args[0];
  if (!linodeId) return newReply('ID Linode belum diberikan.');

  let password = args[1]; // Mengambil password dari argumen kedua (jika ada)
  if (!password) return newReply('Password belum diberikan.');

  let rebuildVPS = async () => {
    try {
      // Rebuild VPS menggunakan API Linode
      const response = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}/rebuild`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        },
        body: JSON.stringify({
          image: 'linode/ubuntu20.04', // Ganti dengan ID atau label image yang ingin digunakan untuk rebuild
          root_pass: password // Menggunakan password yang diberikan
        })
      });

      if (response.ok) {
        newReply('Rebuild VPS berhasil dimulai.');

        // Mendapatkan informasi VPS setelah rebuild
        const vpsInfo = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`
          }
        });

        if (vpsInfo.ok) {
          const vpsData = await vpsInfo.json();
          const ipAddress = vpsData.ipv4[0] || 'Tidak ada IP';

          const textvps = `*VPS SUKSES REBUILD*\nIP VPS: ${ipAddress}\nSYSTEM IMAGE: Ubuntu 20.04\nPASSWORD: ${password}`;
          await sleep(60000);
          kimzz.sendMessage(m.chat, { text: textvps });
        } else {
          newReply('Gagal mendapatkan informasi VPS setelah rebuild.');
        }
      } else {
        const errorData = await response.json();
        newReply('Gagal melakukan rebuild VPS:', errorData.errors[0].reason);
      }
    } catch (error) {
      newReply('Terjadi kesalahan saat melakukan rebuild VPS:', error.message);
    }
  };

  rebuildVPS();
  break;
}

break

case "cekvps": {
  if (!isCreator) return newReply('Maaf, perintah ini hanya untuk pemilik.');

  let linodeId = args[0];
  if (!linodeId) return newReply('ID Linode belum diberikan.');

  // Mendapatkan informasi VPS Linode berdasarkan ID
  const getLinodeInfo = async (linodeId) => {
    try {
      const apiUrl = `https://api.linode.com/v4/linode/instances/${linodeId}`;
      const response = await fetch(apiUrl, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      if (response.ok) {
        const linodeInfo = await response.json();

        const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode
        const ram = `${linodeInfo.specs.memory / 1024} GB`; // RAM VPS dalam GB
        const os = linodeInfo.image.distribution; // Nama OS
        const cpu = `${linodeInfo.specs.vcpus} vCPUs`; // Jumlah vCPUs
        const storage = linodeInfo.specs.disk; // Kapasitas penyimpanan
        const status = linodeInfo.status; // Status VPS

        const createDate = new Date(linodeInfo.created); // Tanggal pembuatan VPS
        const formattedCreateDate = createDate.toLocaleDateString();

        return {
          linodeid: linodeInfo.id,
          label: linodeInfo.label,
          ip: ipAddress,
          ram,
          os,
          cpu,
          storage,
          status,
          createDate: formattedCreateDate
        };
      } else {
        const errorData = await response.json();
        throw new Error(`Gagal memeriksa detail Linode: ${errorData.errors[0].reason}`);
      }
    } catch (error) {
      throw new Error(`Terjadi kesalahan saat memeriksa detail Linode: ${error.message}`);
    }
  };

  getLinodeInfo(linodeId)
    .then((info) => {
      let textku = `*DETAIL VPS LINODE*\nLinode Id: ${info.linodeid}\nLabel: ${info.label}\nIP: ${info.ip}\nRAM: ${info.ram}\nOS: ${info.os}\nCPU: ${info.cpu}\nStorage: ${info.storage}\nStatus: ${info.status}\nCreate On: ${info.createDate}\n`;
      kimzz.sendMessage(m.chat, { text: textku });
    })
    .catch((err) => {
      newReply(err);
      kimzz.sendMessage(m.chat, { text: 'Terjadi kesalahan saat memeriksa detail VPS Linode.' });
    });

  break;
}


break
case "linode1gb": {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  try {
    let linodeData = {
      label: 'my-linode',
      region: 'ap-south', // Ganti dengan region yang diinginkan
      type: 'g6-nanode-1', // Spesifikasi 1GB RAM 1 Core CPU
      image: 'linode/ubuntu20.04', // Ganti dengan image yang diinginkan
      root_pass: '#?KimzzOffcial12+',//miniml 11 huruf
      stackscript_id: null,
      authorized_keys: null,
      backups_enabled: false
    };
    const response = await fetch('https://api.linode.com/v4/linode/instances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LINODE_API_TOKEN}`
      },
      body: JSON.stringify(linodeData)
    });

    const responseData = await response.json();

    if (response.ok) {
      const linodeId = responseData.id;

      // Menunggu hingga Linode selesai dibuat
      newReply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang Linode
      const linodeResponse = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      const linodeInfo = await linodeResponse.json();
      const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode

      let messageText = `Linode berhasil dibuat!\n\n`;
      messageText += `ID: ${linodeId}\n`;
      messageText += `IP Linode: ${ipAddress}\n`;
      messageText += `Password: ${linodeData.root_pass}\n`;

      await kimzz.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat Linode: ${responseData.errors[0].reason}`);
    }
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat membuat Linode: ${err}`);
  }
}
break;

case "linode2gb": {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  try {
    let linodeData = {
      label: 'my-linode',
      region: 'ap-south', // Ganti dengan region yang diinginkan
      type: 'g6-standard-1', // Spesifikasi 1GB RAM 1 Core CPU
      image: 'linode/ubuntu20.04', // Ganti dengan image yang diinginkan
      root_pass: '#?KimzzOffcial+12',//miniml 11 huruf
      stackscript_id: null,
      authorized_keys: null,
      backups_enabled: false
    };
    const response = await fetch('https://api.linode.com/v4/linode/instances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LINODE_API_TOKEN}`
      },
      body: JSON.stringify(linodeData)
    });

    const responseData = await response.json();

    if (response.ok) {
      const linodeId = responseData.id;

      // Menunggu hingga Linode selesai dibuat
      newReply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang Linode
      const linodeResponse = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      const linodeInfo = await linodeResponse.json();
      const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode

      let messageText = `Linode berhasil dibuat!\n\n`;
      messageText += `ID: ${linodeId}\n`;
      messageText += `IP Linode: ${ipAddress}\n`;
      messageText += `Password: ${linodeData.root_pass}\n`;

      await kimzz.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat Linode: ${responseData.errors[0].reason}`);
    }
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat membuat Linode: ${err}`);
  }
}
break;

case "linode16gb": {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  try {
    let linodeData = {
      label: 'my-linode',
      region: 'ap-south', // Ganti dengan region yang diinginkan
      type: 'g6-standard-6', // Spesifikasi 1GB RAM 1 Core CPU
      image: 'linode/ubuntu20.04', // Ganti dengan image yang diinginkan
      root_pass: '#?KimzzOffcial+12',//miniml 11 huruf
      stackscript_id: null,
      authorized_keys: null,
      backups_enabled: false
    };
    const response = await fetch('https://api.linode.com/v4/linode/instances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LINODE_API_TOKEN}`
      },
      body: JSON.stringify(linodeData)
    });

    const responseData = await response.json();

    if (response.ok) {
      const linodeId = responseData.id;

      // Menunggu hingga Linode selesai dibuat
      newReply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang Linode
      const linodeResponse = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      const linodeInfo = await linodeResponse.json();
      const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode

      let messageText = `Linode berhasil dibuat!\n\n`;
      messageText += `ID: ${linodeId}\n`;
      messageText += `IP Linode: ${ipAddress}\n`;
      messageText += `Password: ${linodeData.root_pass}\n`;

      await kimzz.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat Linode: ${responseData.errors[0].reason}`);
    }
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat membuat Linode: ${err}`);
  }
}
break;
            
 case "linode4gb": {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  try {
    let linodeData = {
      label: 'my-linode',
      region: 'ap-south', // Ganti dengan region yang diinginkan
      type: 'g6-standard-2', // Spesifikasi 2GB RAM 1 Core CPU
      image: 'linode/ubuntu20.04', // Ganti dengan image yang diinginkan
      root_pass: '#?KimzzOffcial12+',//miniml 11 huruf
      stackscript_id: null,
      authorized_keys: null,
      backups_enabled: false
    };

    const response = await fetch('https://api.linode.com/v4/linode/instances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LINODE_API_TOKEN}`
      },
      body: JSON.stringify(linodeData)
    });

    const responseData = await response.json();

    if (response.ok) {
      const linodeId = responseData.id;

      // Menunggu hingga Linode selesai dibuat
      newReply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang Linode
      const linodeResponse = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      const linodeInfo = await linodeResponse.json();
      const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode

      let messageText = `Linode berhasil dibuat!\n\n`;
      messageText += `ID: ${linodeId}\n`;
      messageText += `IP Linode: ${ipAddress}\n`;
      messageText += `Password: ${linodeData.root_pass}\n`;

      await kimzz.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat Linode: ${responseData.errors[0].reason}`);
    }
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat membuat Linode: ${err}`);
  }
}
break;

case "linode8gb": {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  try {
    let linodeData = {
      label: 'my-linode',
      region: 'ap-south', // Ganti dengan region yang diinginkan
      type: 'g6-standard-4', // Spesifikasi 2GB RAM 1 Core CPU
      image: 'linode/ubuntu20.04', // Ganti dengan image yang diinginkan
      root_pass: '#?KimzzOffcial12+',//miniml 11 huruf
      stackscript_id: null,
      authorized_keys: null,
      backups_enabled: false
    };

    const response = await fetch('https://api.linode.com/v4/linode/instances', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LINODE_API_TOKEN}`
      },
      body: JSON.stringify(linodeData)
    });

    const responseData = await response.json();

    if (response.ok) {
      const linodeId = responseData.id;

      // Menunggu hingga Linode selesai dibuat
      newReply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang Linode
      const linodeResponse = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${LINODE_API_TOKEN}`
        }
      });

      const linodeInfo = await linodeResponse.json();
      const ipAddress = linodeInfo.ipv4[0]; // Alamat IP Linode

      let messageText = `Linode berhasil dibuat!\n\n`;
      messageText += `ID: ${linodeId}\n`;
      messageText += `IP Linode: ${ipAddress}\n`;
      messageText += `Password: ${linodeData.root_pass}\n`;

      await kimzz.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat Linode: ${responseData.errors[0].reason}`);
    }
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat membuat Linode: ${err}`);
  }
}
break;
            
case "saldolinode":
  if (!isCreator) return newReply(mess.only.owner);

  // Endpoint untuk mengambil informasi saldo promosi Linode
  const linodePromotionsEndpoint = 'https://api.linode.com/v4/profile';

  // Konfigurasi untuk melakukan permintaan ke API Linode
  const config = {
    headers: {
      'Authorization': `Bearer ${LINODE_API_TOKEN}`
    }
  };

  // Mengambil informasi saldo promosi dari Linode
  axios.get(linodePromotionsEndpoint, config)
    .then(response => {
      // Periksa apakah saldo promosi tersedia dalam respons
      if (response.data && Array.isArray(response.data.data)) {
        // Saldo promosi dapat ada dalam elemen pertama jika ada
        const saldoPromosi = response.data.data[0].balance;
        const teksSaldo = `Sisa Kredit Promosi Linode Dalam Akun Anda Adalah $${saldoPromosi}`;
        newReply(teksSaldo);
      } else {
        newReply('Informasi saldo promosi tidak ditemukan atau akun tidak memiliki saldo promosi.');
      }
    })
    .catch(error => {
      console.error(error);
      newReply('Terjadi kesalahan saat mengambil informasi saldo promosi.');
    });

  break;
        
case "resetpassword": {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
  let linodeId = args[0];
  let newPassword = args[1];
  
  if (!linodeId || !newPassword) {
    return newReply("Format: !resetpassword [Linode ID] [New Password]");
  }
  
  // Periksa apakah kata sandi memenuhi persyaratan keamanan yang diharapkan
  if (newPassword.length < 8) {
    return newReply("Kata sandi harus memiliki setidaknya 8 karakter.");
  }
  
  try {
    const resetPassword = async () => {
      try {
        const response = await fetch(`https://api.linode.com/v4/linode/instances/${linodeId}/password`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`
          },
          body: JSON.stringify({ root_pass: newPassword })
        });
        
        if (response.ok) {
          newReply(`Kata sandi VPS Linode ID ${linodeId} berhasil direset.`);
        } else {
          const responseData = await response.json();
          throw new Error(`Gagal mereset kata sandi VPS Linode: ${responseData.errors[0].reason}`);
        }
      } catch (error) {
        newReply(`Terjadi kesalahan saat mereset kata sandi VPS Linode: ${error}`);
      }
    };
    
    resetPassword();
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat mereset kata sandi VPS Linode: ${err}`);
  }
}
break;



        
    case 'listlinode': {
  if (!isCreator) return newReply("Anda bukan pemilik.");

  try {
    const getLinodes = async () => {
      try {
        const response = await fetch('https://api.linode.com/v4/linode/instances', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`
          }
        });
        const data = await response.json();
        return data.data || [];
      } catch (error) {
        newReply('Error fetching Linodes: ' + error);
        return [];
      }
    };

    getLinodes().then(linodes => {
      let totalvps = linodes.length;
      let message = `List VPS Linode Anda: ${totalvps}\n\n▬▭▬▭▬▭▬▭▬▭▬▭▬\n`;

      if (linodes.length === 0) {
        message += 'Tidak ada VPS yang tersedia.';
      } else {
        linodes.forEach(linode => {
          message += `- Linode Id: ${linode.id}\n- Label: ${linode.label}\n- Region: ${linode.region}\n- IP: ${linode.ipv4[0]}\n- Ram: ${linode.specs.memory / 1024} GB\n- Cpu: ${linode.specs.vcpus} CPU\n- Status: ${linode.status}\n- Harga: $\n▬▬▭▬▭▬▭▬▭▬▭▬\n`;
        });
      }
      kimzz.sendMessage(m.chat, { text: message });
    });
  } catch (err) {
    newReply('Terjadi kesalahan saat mengambil data Linode: ' + err);
  }

  break;
}
     
        
 case "offlinode": {
  if (!isCreator) return newReply(`Sok Asik Anjg`);
  
  let linodeId = args[0];
  if (!linodeId) return newReply('ID Linode belum diberikan.');

  async function turnOffLinode() {
    try {
      const response = await axios.post(
        `https://api.linode.com/v4/linode/instances/${linodeId}/shutdown`,
        {},
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`,
          },
        }
      );

      if (response.status === 200) {
        newReply('VPS (Linode) sedang dimatikan...');
      } else {
        newReply('Gagal mematikan VPS (Linode).');
      }
    } catch (error) {
      newReply('Terjadi kesalahan saat mematikan VPS (Linode):', error.message);
    }
  }

  turnOffLinode();
  break;
}

case "onlinode": {
  if (!isCreator) return newReply(`Sok Asik Anjg`);
  
  let linodeId = args[0];
  if (!linodeId) return newReply('ID Linode belum diberikan.');

  async function turnOnLinode() {
    try {
      const response = await axios.post(
        `https://api.linode.com/v4/linode/instances/${linodeId}/boot`,
        {},
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`,
          },
        }
      );

      if (response.status === 200) {
        newReply('VPS (Linode) sedang diaktifkan...');
      } else {
        newReply('Gagal mengaktifkan VPS (Linode).');
      }
    } catch (error) {
      newReply('Terjadi kesalahan saat mengaktifkan VPS (Linode):', error.message);
    }
  }

  turnOnLinode();
  break;
}
case "rebootlinode": {
  if (!isCreator) return newReply(`Sok Asik Anjg`);
  
  let linodeId = args[0];
  if (!linodeId) return newReply('ID Linode belum diberikan.');

  async function rebootLinode() {
    try {
      const response = await axios.post(
        `https://api.linode.com/v4/linode/instances/${linodeId}/reboot`,
        {},
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${LINODE_API_TOKEN}`,
          },
        }
      );

      if (response.status === 200) {
        newReply('VPS (Linode) sedang direboot...');
      } else {
        newReply('Gagal me-reboot VPS (Linode).');
      }
    } catch (error) {
      newReply('Terjadi kesalahan saat me-reboot VPS (Linode):', error.message);
    }
  }

  rebootLinode();
}
// create vps digital ocean
break    
case "sisadroplet":{
if (!isCreator) return newReply(`Ga Usah Sok Asik Anjg`)
async function getDropletInfo() {
  try {
    const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
      headers: {
        Authorization: `Bearer ${API_TOKEN}`,
      },
    });

    const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
      headers: {
        Authorization: `Bearer ${API_TOKEN}`,
      },
    });

    if (accountResponse.status === 200 && dropletsResponse.status === 200) {
      const dropletLimit = accountResponse.data.account.droplet_limit;
      const dropletsCount = dropletsResponse.data.droplets.length;
      const remainingDroplets = dropletLimit - dropletsCount;

      return {
        dropletLimit,
        remainingDroplets,
        totalDroplets: dropletsCount,
      };
    } else {
      throw new Error('Gagal mendapatkan data akun DigitalOcean atau droplet.');
    }
  } catch (error) {
    throw error;
  }
}

// Definisikan fungsi untuk mengeksekusi kasus "sisadroplet"
async function sisadropletHandler() {
  try {
    if (!isCreator) {
      return m.reply('Lu Siapanya Gua Anjg');
    }

    const dropletInfo = await getDropletInfo();
    m.reply(`*Sisa Droplet Yang Dapat Anda Pakai: ${dropletInfo.remainingDroplets}*

*Total Droplet Yang Sudah Terpakai: ${dropletInfo.totalDroplets}*`);
  } catch (error) {
    m.reply(`Terjadi kesalahan: ${error.message}`);
  }
}

  sisadropletHandler();
  break;
}
case "restartvps": {
    if (!isCreator) return newReply(`Sok Asik Anjg`)
  let dropletId = args[0];
  if (!dropletId) return m.reply('ID droplet belum diberikan.');

  // Fungsi untuk melakukan restart VPS berdasarkan ID droplet
  const restartVPS = async (dropletId) => {
    try {
      const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_TOKEN}`
        },
        body: JSON.stringify({
          type: 'reboot'
        })
      });

      if (response.ok) {
        const data = await response.json();
        return data.action;
      } else {
        const errorData = await response.json();
        newReply(`Gagal melakukan restart VPS: ${errorData.message}`);
      }
    } catch (error) {
      newReply('Terjadi kesalahan saat melakukan restart VPS:', error.message);
      newReply('Terjadi kesalahan saat melakukan restart VPS.');
    }
  };

  restartVPS(dropletId)
    .then((action) => {
      newReply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
    })
    .catch((err) => {
      newReply(err);
    });

  break;
}
case "turnoff": {
  if (!isCreator) return newReply(`Sok Asik Anjg`);
  
  let dropletId = args[0];
  if (!dropletId) return m.reply('ID droplet belum diberikan.');

  async function turnOffDroplet() {
    try {
      const response = await axios.post(
        `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`,
        {
          type: 'power_off',
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${API_TOKEN}`,
          },
        }
      );

      if (response.status === 201 && response.data.action && response.data.action.status === 'in-progress') {
        newReply('VPS (Droplet) sedang dimatikan...');
      } else {
        newReply('Gagal mematikan VPS (Droplet).');
      }
    } catch (error) {
      newReply('Terjadi kesalahan saat mematikan VPS (Droplet):', error.message);
    }
  }

  turnOffDroplet();
  break;
}

        
case "turnon": {
  if (!isCreator) return newReply(`Sok Asik Anjg`);
  
  let dropletId = args[0];
  if (!dropletId) return m.reply('ID droplet belum diberikan.');

  async function turnOnDroplet() {
    try {
      const response = await axios.post(
        `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`,
        {
          type: 'power_on',
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${API_TOKEN}`,
          },
        }
      );

      if (response.status === 201 && response.data.action && response.data.action.status === 'in-progress') {
        newReply('VPS (Droplet) sedang dihidupkan...');
      } else {
        newReply('Gagal menghidupkan VPS (Droplet).');
      }
    } catch (error) {
      newReply('Terjadi kesalahan saat menghidupkan VPS (Droplet):', error.message);
    }
  }

  turnOnDroplet();
  break;
}
        
        
case "rebuild": {
  if (!isCreator) return m.reply(`Lu Siapanya Gua Anjg Gausah Nyuruh Nyuruh Gua Anjg`);

  let dropletId = args[0];
  if (!dropletId) return m.reply('ID droplet belum diberikan.');

  let rebuildVPS = async () => {
    try {
      // Rebuild droplet menggunakan API DigitalOcean
      const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_TOKEN}`
        },
        body: JSON.stringify({
          type: 'rebuild',
          image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
        })
      });

      if (response.ok) {
        const data = await response.json();
        newReply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);

        // Mendapatkan informasi VPS setelah rebuild
        const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${API_TOKEN}`
          }
        });

        if (vpsInfo.ok) {
          const vpsData = await vpsInfo.json();
          const droplet = vpsData.droplet;
          const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
          const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP';

          const textvps = `*VPS SUKSES REBUILD*\nIP VPS: ${ipAddress}\nSYSTEM IMAGE: ${droplet.image.slug}`;
          await sleep(60000) 
 kimzz.sendMessage(m.chat, { text: textvps });
        } else {
          newReply('Gagal mendapatkan informasi VPS setelah rebuild.');
        }
      } else {
        const errorData = await response.json();
        newReply('Gagal melakukan rebuild VPS:', errorData.message);
      }
    } catch (error) {
      newReply('Terjadi kesalahan saat melakukan rebuild VPS:', error);
    }
  };

  rebuildVPS();
}
break;

        case "deldroplet": {
  if (!isCreator) return m.reply('Maaf, command ini hanya untuk pemilik.');

  let dropletId = args[0];
  if (!dropletId) return m.reply('ID droplet belum diberikan.');

  let deleteDroplet = async () => {
    try {
      let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_TOKEN}`
        }
      });

      if (response.ok) {
        m.reply('Droplet berhasil dihapus.');
      } else {
        const errorData = await response.json();
        throw new Error(`Gagal menghapus droplet: ${errorData.message}`);
      }
    } catch (error) {
      console.error('Terjadi kesalahan saat menghapus droplet:', error);
      m.reply('Terjadi kesalahan saat menghapus droplet.');
    }
  };

  deleteDroplet();

  break;
}
 case "listdroplet": {
  if (!isCreator) return m.reply("Anda bukan pemilik.");

  try {
    const getDroplets = async () => {
      try {
        const response = await fetch('https://api.digitalocean.com/v2/droplets', {
          headers: {
            Authorization: "Bearer " + API_TOKEN
          }
        });
        const data = await response.json();
        return data.droplets || [];
      } catch (error) {
        newReply('Error fetching droplets: ' + error);
        return [];
      }
    };

    getDroplets().then(droplets => {
      let totalvps = droplets.length;
      let mesej = `List Droplet Digital Ocean Anda: ${totalvps}\n\n▬▭▬▭▬▭▬▭▬▭▬▭▬\n`;

      if (droplets.length === 0) {
        mesej += 'Tidak ada Droplet yang tersedia.';
      } else {
        droplets.forEach(droplet => {
          const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
          const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP';
          mesej += `- Droplet Id: ${droplet.id}\n- Hostname: ${droplet.name}\n- Username Login: root\n- IP: ${ipAddress}\n- Ram: ${droplet.memory} MB\n- Cpu: ${droplet.vcpus} CPU\n- OS: ${droplet.image.distribution}\n- Storage: ${droplet.disk} GB\n- Status: ${droplet.status}\n▬▭▬▭▬▭▬▭▬▭▬▭▬\n`;
        });
      }
      kimzz.sendMessage(m.chat, { text: mesej });
    });
  } catch (err) {
    newReply('Terjadi kesalahan saat mengambil data droplet: ' + err);
  }

  break;
}
    
 case "cekdroplet": {
  if (!isCreator) return m.reply(`Ngapain? Kepo Amat Dah`);

  let dropletId = args[0];
  if (!dropletId) return m.reply('ID droplet belum diberikan.');

  // Mendapatkan informasi droplet (VPS) berdasarkan ID
  const getDropletInfo = async (dropletId) => {
    try {
      const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}`;
      const response = await fetch(apiUrl, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_TOKEN}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        const droplet = data.droplet;
        const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
        const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP';
        const vpsRam = droplet.memory / 1024;

        return {
          dropletid: droplet.id,
          username: droplet.name,
          ip: ipAddress,
          ram: `${vpsRam} GB`,
          os: droplet.image.distribution,
          cpu: droplet.vcpus > 1 ? `${droplet.vcpus} vCPU` : `${droplet.vcpus} vCPUs`,
          storage: droplet.disk,
          status: droplet.status // Menambahkan status VPS
        };
      } else {
        const errorData = await response.json();
        throw new Error(`Gagal memeriksa detail droplet: ${errorData.message}`);
      }
    } catch (error) {
      newReply('Terjadi kesalahan saat memeriksa detail droplet:', error.message);
      throw new Error('Terjadi kesalahan saat memeriksa detail droplet.');
    }
  };

  getDropletInfo(dropletId)
    .then((info) => {
      let textku = `*DETAIL VPS ANDA*\nDroplet Id: ${info.dropletid}\nHostname: ${info.username}\nIpv4 : ${info.ip}\nRam : ${info.ram}\nOS : ${info.os}\nCPU: ${info.cpu}\nStorage: ${info.storage}\nStatus : ${info.status}`;
      kimzz.sendMessage(m.chat, { text: textku });
    })
    .catch((err) => {
      newReply(err);
      kimzz.sendMessage(m.chat, { text: 'Terjadi kesalahan saat memeriksa detail VPS.' });
    });
break;
}
break
    case "vps1g1c": {
if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
let hostname = args[0];
if (!hostname) return m.reply('Masukan Hostname Vps.');

  try {
    let dropletData = {
      name: hostname,
      region: 'sgp1',
      size: 's-1vcpu-1gb',
      image: 'ubuntu-20-04-x64',
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T']
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + API_TOKEN
      },
      body: JSON.stringify(dropletData)
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      newReply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer " + API_TOKEN
        }
      });

      let dropletData = await dropletResponse.json();
      // Memeriksa apakah ada alamat IP VPS yang tersedia
      let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 ? dropletData.droplet.networks.v4[0].ip_address : "Tidak ada alamat IP yang tersedia";

      let messageText = `VPS berhasil dibuat!\n\n`;

      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}\n`;

      await kimzz.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat membuat VPS: ${err}`);
  }}
break

    case "vps2g1c": {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
    let hostname = args[0];
  if (!hostname) return newReply('Masukan Hostname Vps.');

  try {
    let dropletData = {
      name: hostname,
      region: 'sgp1',
      size: 's-1vcpu-2gb',
      image: 'ubuntu-20-04-x64',
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T']
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + API_TOKEN
      },
      body: JSON.stringify(dropletData)
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      newReply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer " + API_TOKEN
        }
      });

      let dropletData = await dropletResponse.json();
      // Memeriksa apakah ada alamat IP VPS yang tersedia
      let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 ? dropletData.droplet.networks.v4[0].ip_address : "Tidak ada alamat IP yang tersedia";

      let messageText = `VPS berhasil dibuat!\n\n`;

      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}\n`;

      await kimzz.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat membuat VPS: ${err}`);
  }}
break  
 
    case "vps2g2c": {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
    let hostname = args[0];
  if (!hostname) return m.reply('Masukan Hostname Vps.');

  try {
    let dropletData = {
      name: hostname,
      region: 'sgp1',
      size: 's-2vcpu-2gb',
      image: 'ubuntu-20-04-x64',
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T']
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + API_TOKEN
      },
      body: JSON.stringify(dropletData)
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      newReply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer " + API_TOKEN
        }
      });

      let dropletData = await dropletResponse.json();
      // Memeriksa apakah ada alamat IP VPS yang tersedia
      let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 ? dropletData.droplet.networks.v4[0].ip_address : "Tidak ada alamat IP yang tersedia";

      let messageText = `VPS berhasil dibuat!\n\n`;

      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}\n`;

      await kimzz.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat membuat VPS: ${err}`);
  }}
break      
    case "vps4g2c": {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
    let hostname = args[0];
  if (!hostname) return m.reply('Masukan Hostname Vps.');

  try {
    let dropletData = {
      name: hostname,
      region: 'sgp1',
      size: 's-2vcpu-4gb',
      image: 'ubuntu-20-04-x64',
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T']
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + API_TOKEN
      },
      body: JSON.stringify(dropletData)
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      newReply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer " + API_TOKEN
        }
      });

      let dropletData = await dropletResponse.json();
      // Memeriksa apakah ada alamat IP VPS yang tersedia
      let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 ? dropletData.droplet.networks.v4[0].ip_address : "Tidak ada alamat IP yang tersedia";

      let messageText = `VPS berhasil dibuat!\n\n`;

      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}\n`;

      await kimzz.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat membuat VPS: ${err}`);
  }}
break        
     case "vps8g4c": {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
    let hostname = args[0];
  if (!hostname) return m.reply('Masukan Hostname Vps.');

  try {
    let dropletData = {
      name: hostname,
      region: 'sgp1',
      size: 's-4vcpu-8gb',
      image: 'ubuntu-20-04-x64',
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T']
    };

    let password = generateRandomPassword();
    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + API_TOKEN
      },
      body: JSON.stringify(dropletData)
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;

      // Menunggu hingga VPS selesai dibuat
      newReply(`Tunggu Sebentar...`);
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi lengkap tentang VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': "Bearer " + API_TOKEN
        }
      });

      let dropletData = await dropletResponse.json();
      // Memeriksa apakah ada alamat IP VPS yang tersedia
      let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 ? dropletData.droplet.networks.v4[0].ip_address : "Tidak ada alamat IP yang tersedia";

      let messageText = `VPS berhasil dibuat!\n\n`;

      messageText += `ID: ${dropletId}\n`;
      messageText += `IP VPS: ${ipVPS}\n`;
      messageText += `Password: ${password}\n`;

      await kimzz.sendMessage(m.chat, { text: messageText });
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
  } catch (err) {
    console.error(err);
    newReply(`Terjadi kesalahan saat membuat VPS: ${err}`);
  }}
break
case 'email' :{
if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
let emailkey = args[0];
if (!emailkey) return m.reply('Contoh .email kimzz');
const key = '_kD3NRE-DPufQjPpEdQuZ_JF3HfoZ3sOt75-PZ-y'; // Gantikan dengan alamat e-mel yang sebenar
const accountIdentifier = 'a17dee7f8fec767cf5f31beaca174d0e'; // Gantikan dengan pengenal akaun Cloudflare yang betul

const options = {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer U0HRvg6b-yCMNdJPAZGBv57WBCJwS8NH3Q3AzOwo', // Gantikan dengan token autentikasi anda
  },
  body: JSON.stringify({email: `${emailkey}@kimzzoffc.me`}) // Isikan dengan data JSON yang ingin anda hantar
};

const url = `https://api.cloudflare.com/client/v4/accounts/${accountIdentifier}/email/routing/addresses`;

fetch(url, options)
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      const result = data.result;
      let replyMessage = `_*Berhasil Membuat Email*_\n\n`
      replyMessage += `Email: ${result.email}\n\nCreated: ${result.created}`;
      newReply(replyMessage);
    } else {
      newReply('Permintaan tidak berjaya: ' + JSON.stringify(data.errors));
    }
  })
  .catch(err => newReply('Ralat: ' + err));
}
break
case 'listemail': {
  if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);

  const accountIdentifier = 'a17dee7f8fec767cf5f31beaca174d0e'; // Gantikan dengan pengenal akaun Cloudflare yang betul

  const options = {
    method: 'GET', // Ubah ke 'GET'
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer U0HRvg6b-yCMNdJPAZGBv57WBCJwS8NH3Q3AzOwo', // Gantikan dengan token autentikasi anda
    },
  };

  const url = `https://api.cloudflare.com/client/v4/accounts/${accountIdentifier}/email/routing/addresses`;

  fetch(url, options)
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        const results = data.result;

        if (results.length > 0) {
          let message = `*Daftar Email Yang Dibuat*\n\n`;

          results.forEach((result, index) => {
            message += `No: ${index + 1}\nEmail: ${result.email}\nTag: ${result.tag}\n\n`;
          });

          // Menghantar mesej tunggal yang mengandungi semua mesej
          newReply(message);
        } else {
          newReply('Tiada rekod alamat e-mel ditemui.');
        }
      } else {
        newReply('Permintaan tidak berjaya: ' + JSON.stringify(data.errors));
      }
    })
    .catch(err => newReply('Ralat: ' + err));
}
break
case 'delemail' :{
if (!isCreator) return newReply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
let emailnya = args[0];
if (!emailnya) return m.reply('Contoh .delemail tag');
const key = '_kD3NRE-DPufQjPpEdQuZ_JF3HfoZ3sOt75-PZ-y'; // Gantikan dengan alamat e-mel yang sebenar
const accountIdentifier = 'a17dee7f8fec767cf5f31beaca174d0e'; // Gantikan dengan pengenal akaun Cloudflare yang betul

const options = {
  method: 'DELETE',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer U0HRvg6b-yCMNdJPAZGBv57WBCJwS8NH3Q3AzOwo', // Gantikan dengan token autentikasi anda
  },
};

const url = `https://api.cloudflare.com/client/v4/accounts/${accountIdentifier}/email/routing/addresses/${emailnya}`;

fetch(url, options)
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      const result = data.result;
      let replyMessage = `_*Berhasil Menghapus Alamat Email Tersebut Dari Daftar Email*_\n`;
      newReply(replyMessage);
    } else {
      newReply('Permintaan tidak berjaya: ' + JSON.stringify(data.errors));
    }
  })
  .catch(err => newReply('Ralat: ' + err));
}
break
case "bcgc":
        case "bcgrup":
          {
            if (!isCreator) throw mess.owner;
            if (!text) throw `Menu ini hanya akan mengirim broadcast ke grup.\n\nContoh: ${prefix + command} pengumuman besok libur`;
            let getGroups = await kimzz.groupFetchAllParticipating();
            let groups = Object.entries(getGroups)
              .slice(0)
              .map((entry) => entry[1]);
            let anu = groups.map((v) => v.id);
            m.reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 3.0} detik`);
            for (let i of anu) {
              await sleep (3000)
              let txt = `${text}`;
              kimzz.sendText(i, txt);
            }
            m.reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`);
          }
break
case "jpmgc":
case "postgc": {
  if (!isCreator) return m.reply('Khusus Owner');
  if (!text) return m.reply(`*Penggunaan Salah. Silakan Gunakan Seperti Ini*\n${prefix + command} teks|jeda\n\nReply Gambar Untuk Mengirim Gambar Ke Semua Group\nUntuk Jeda, gunakan delay dalam milidetik (misal: 1000 = 1 detik)`);

  await m.reply("_Waiting in progress !!_");
  let getGroups = await kimzz.groupFetchAllParticipating();
  let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
  let anu = groups.map((v) => v.id);

  for (let xnxx of anu) {
    let metadat72 = await kimzz.groupMetadata(xnxx);
    let participanh = await metadat72.participants;
    
    if (/image/.test(mime)) {
      media = await kimzz.downloadAndSaveMediaMessage(quoted);
      mem = await TelegraPh(media);
      await kimzz.sendMessage(xnxx, { image: { url: mem }, caption: text.split('|')[0] });
      await sleep(text.split('|')[1]);
    } else {
      await kimzz.sendMessage(xnxx, { text: text.split('|')[0] });
      await sleep(text.split('|')[1]);
    }
  }

  m.reply("*SUCCESSFUL ✅");
}
break
case 'toonce':
case 'toviewonce': {
  if (!isMedia) return newReply("Reply with an image or audio");
  if (/image/.test(mime)) {
    anuan = await kimzz.downloadAndSaveMediaMessage(quoted);
    kimzz.sendMessage(m.chat, { image: { url: anuan }, caption: `Here you go!`, fileLength: "999", viewOnce: true }, { quoted: m });
  } else if (/audio/.test(mime)) {
    anuan = await kimzz.downloadAndSaveMediaMessage(quoted);
    kimzz.sendMessage(m.chat, { audio: { url: anuan }, caption: `Here you go!`, fileLength: "99999999", viewOnce: true }, { quoted: m });
  } else if (/video/.test(mime)) {
    anuanuan = await kimzz.downloadAndSaveMediaMessage(quoted);
    kimzz.sendMessage(m.chat, { video: { url: anuanuan }, caption: `Here you go!`, fileLength: "999999", viewOnce: true }, { quoted: m });
  }
}
break
case 'toimg': {
	kimzzWait()
	const getRandom = (ext) => {
            return `${Math.floor(Math.random() * 10000)}${ext}`
        }
        if (!m.quoted) return reply(`_Reply to Any Sticker._`)
        let mime = m.quoted.mtype
if (mime =="imageMessage" || mime =="stickerMessage")
{
        let media = await kimzz.downloadAndSaveMediaMessage(m.quoted)
        let name = await getRandom('.png')
        exec(`ffmpeg -i ${media} ${name}`, (err) => {
        	fs.unlinkSync(media)
            let buffer = fs.readFileSync(name)
            kimzz.sendMessage(m.chat, { image: buffer }, { quoted: m })      
fs.unlinkSync(name)
        })
        
} else return reply(`Please reply to non animated sticker`)
}
break
case "sticker": 
case "s": {
if (!isCreator) return kimzzOwner()
if (!quoted) return reply(`Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await kimzz.sendImageAsSticker(from, media, m, { packname: '', author: 'kimzz' })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik')
let media = await quoted.download()
let encmedia = await kimzz.sendVideoAsSticker(from, media, m, { packname: '', author: 'kimzz' })
await fs.unlinkSync(encmedia)
} else {
reply(`Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik`)
}
}
break 
case 'del':{
kimzz.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: true,
id: m.quoted.id,
participant: m.quoted.sender
}
})
}
break
case 'smeme':
 if (!text) throw `Balas Image Dengan Caption ${prefix + command}`
if (!quoted) throw `Balas Image Dengan Caption ${prefix + command}`
if (/image/.test(mime)) {
reply(mess.wait)
mee = await kimzz.downloadAndSaveMediaMessage(quoted)
mem = await TelegraPh(mee)
kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${text}.png?background=${mem}`)
kimzz.sendImageAsSticker(m.chat, kaytid, m, { packname: '', author: 'kimzz' })
} 
break
case 'enc': {
            if (!isCreator) return kimzzWait()
            if (!text) return reply(`Contoh ${prefix+command} const adrian = require('adrian-api')`)
            let meg = await obfus(text)
            reply(`${meg.result}`)
        } 
break        
case 'delsampah': {
      try {
      const { tmpdir } = require('os')
      const { join } = require('path')
      const { readdirSync, statSync, unlinkSync, existsSync, readFileSync, watch } = require('fs')
      const session = [tmpdir(), join(__dirname, './kimzz')]
      const filename = []
      session.forEach(dirname => readdirSync(dirname).forEach(file => filename.push(join(dirname, file))))
      
      filename.forEach(file => {
        const stats = statSync(file)
        if (file == 'creds.json') return
        unlinkSync(file)
      })
    reply('Sukses Menghapus sampah Session')
    } catch (error) {
   reply('tiada sampah yang dikesan')
    }
}
break

default:
}
if (budy.startsWith('=>')) {
if (!isCreator) return kimzzOwner()
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return newReply(bang)
}
try {
newReply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
newReply(String(e))
}
}
if (budy.startsWith('$')) {
if (!isCreator) return kimzzOwner()
exec(budy.slice(2), (err, stdout) => {
if (err) return newReply(err)
if (stdout) return newReply(stdout)
})
}
if (budy.startsWith('x')) {
if (!isCreator) return kimzzOwner()
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
m.reply(String(err))
}
}
} catch (err) {
m.reply(util.format(err))
}
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})
